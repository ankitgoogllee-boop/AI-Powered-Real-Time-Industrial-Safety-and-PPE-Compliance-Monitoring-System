import os
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"

import sys
import argparse
import random
import time
from flask import Flask, Response, jsonify, request

from vision import VisionProcessor, is_yolo_supported

# Setup argument parser
parser = argparse.ArgumentParser(description="IndustrialVision AI Flask Server")
parser.add_argument("--host", default="127.0.0.1", help="Host address")
parser.add_argument("--port", type=int, default=5000, help="Port number")
parser.add_argument("--test", action="store_true", help="Run self-test and exit")
args, unknown = parser.parse_known_args()

# Initialize Flask, serving static assets from the current directory
app = Flask(__name__, static_folder=".", static_url_path="")

# Initialize the global VisionProcessor
# Auto-detect local custom model weights named 'best.pt'
base_dir = os.path.dirname(os.path.abspath(__file__))
default_model_path = None
best_path = os.path.join(base_dir, "best.pt")
if os.path.exists(best_path):
    default_model_path = best_path
    print(f"[app.py] Auto-detecting local custom model weights: {default_model_path}")

vision_processor = VisionProcessor(source="0", model_path=default_model_path)
vision_processor.last_alerts = []

# Mock data for historical sensors
base_telemetry = {
    "temp": 24.2,
    "gas": 0.02,
    "humidity": 45.8,
    "noise": 72.4
}

@app.route("/")
def index():
    """Serves the main dashboard application UI page"""
    return app.send_static_file("index.html")

@app.route("/api/status")
def status():
    """Returns general status metadata of the backend"""
    return jsonify({
        "status": "online",
        "yolo_available": YOLO_AVAILABLE,
        "model_loaded": vision_processor.model is not None,
        "model_path": vision_processor.model_path or "Default (OpenCV Fallback)",
        "source": str(vision_processor.source),
        "confidence_threshold": vision_processor.confidence_threshold,
        "active_detectors": vision_processor.active_detectors
    })

def gen_frames():
    """Inference generator loop for MJPEG video stream"""
    while True:
        # Control FPS to avoid high CPU usage
        time.sleep(0.04)  # ~25 FPS
        try:
            frame_bytes, alerts = vision_processor.get_frame()
            vision_processor.last_alerts = alerts
            
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
        except Exception as e:
            print(f"[app.py] Error in frame generation: {e}")
            time.sleep(1)

@app.route("/video_feed")
def video_feed():
    """Video streaming route. Point img src in HTML to this URL"""
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route("/api/telemetry")
def telemetry():
    """Returns real-time simulated environment telemetry + active safety violations"""
    # Create slight random fluctuations for realistic HUD updates
    temp_noise = random.uniform(-0.15, 0.15)
    gas_noise = random.uniform(-0.001, 0.001)
    hum_noise = random.uniform(-0.2, 0.2)
    noise_noise = random.uniform(-0.6, 0.6)
    
    # Gas alert triggers in Zone C if simulated leak or custom setting
    # We retrieve the current live zone key from the vision processor
    active_zone = vision_processor.active_zone_key
    
    gas_val = max(0.001, base_telemetry["gas"] + gas_noise)
    if active_zone == "chemical":
        gas_val = max(0.03, gas_val)  # Slightly higher gas in Chemical Room
        
    noise_val = max(30.0, base_telemetry["noise"] + noise_noise)
    if active_zone == "assembly":
        noise_val = max(80.0, noise_val) # Louder noise on assembly line
        
    telemetry_data = {
        "temp": round(base_telemetry["temp"] + temp_noise, 1),
        "gas": round(gas_val, 3),
        "humidity": round(base_telemetry["humidity"] + hum_noise, 1),
        "noise": round(noise_val, 1)
    }
    
    return jsonify({
        "telemetry": telemetry_data,
        "active_alerts": vision_processor.last_alerts
    })

@app.route("/api/config", methods=["POST"])
def update_config():
    """Updates vision configuration parameters (source, model path, triggers, overlays)"""
    data = request.json or {}
    print(f"[app.py] Updating config: {data}")
    
    # Handle camera source change
    if "cameraSource" in data:
        new_source = data["cameraSource"]
        if str(new_source) != str(vision_processor.source):
            try:
                vision_processor.set_source(new_source)
            except Exception as e:
                return jsonify({"status": "error", "message": f"Failed to set source: {e}"}), 400
                
    # Handle custom model reload
    if "modelPath" in data:
        new_model = data["modelPath"]
        if new_model != vision_processor.model_path:
            try:
                success = vision_processor.load_model(new_model)
                if not success and new_model:
                    return jsonify({"status": "warning", "message": "Failed to load model file, using default fallback"}), 200
            except Exception as e:
                return jsonify({"status": "error", "message": f"Model load error: {e}"}), 400
                
    # Update other vision processor configs
    vision_processor.update_config(data)
    
    return jsonify({
        "status": "success",
        "yolo_available": is_yolo_supported(),
        "model_loaded": vision_processor.model is not None,
        "model_path": vision_processor.model_path or "Default (OpenCV Fallback)",
        "source": str(vision_processor.source)
    })

@app.route("/api/login", methods=["POST"])
def login():
    """Handles secure user authentication in Python"""
    data = request.json or {}
    username = data.get("username")
    password = data.get("password")
    
    # Default credentials check
    if username == "admin" and password == "admin123":
        return jsonify({
            "status": "success",
            "message": "Authentication successful"
        })
    else:
        return jsonify({
            "status": "error",
            "message": "Invalid username or password"
        }), 401

@app.route("/api/search")
def search():
    """Handles search queries for workers, zones, and alerts in Python"""
    query = request.args.get("q", "").lower().strip()
    if not query:
        return jsonify([])
        
    results = []
    
    # 1. Search simulated workers in VisionProcessor
    for w in vision_processor.sim_workers:
        name = w["name"].lower()
        w_id = w["id"].lower()
        if query in name or query in w_id or query in w["state"].lower():
            compliance = "Non-Compliant" if (not w["ppe"]["helmet"] or not w["ppe"]["vest"]) else "Compliant"
            results.append({
                "type": "worker",
                "name": f"{w['id']} | {w['name']}",
                "location": "Active Area Feed",
                "status": f"{w['state'].upper()} ({compliance})",
                "zone_key": vision_processor.active_zone_key
            })
            
    # 2. Search facility zones
    zones_map = {
        "dock": "Zone A: Main Loading Dock",
        "assembly": "Zone B: Assembly Line B",
        "chemical": "Zone C: Chemical Storage",
        "corridor": "Zone D: Warehouse Hallway"
    }
    for key, name in zones_map.items():
        if query in name.lower() or query in key.lower():
            results.append({
                "type": "zone",
                "name": name,
                "location": name,
                "status": "MONITORING ACTIVE",
                "zone_key": key
            })
            
    # 3. Search active alerts
    for alert in vision_processor.last_alerts:
        details = alert["details"].lower()
        alert_type = alert["type"].lower()
        if query in details or query in alert_type:
            results.append({
                "type": "alert",
                "name": alert["details"],
                "location": f"Camera ({alert['location'].upper()})",
                "status": f"ACTIVE ({alert['severity'].upper()})",
                "zone_key": alert["location"]
            })
            
    return jsonify(results[:6])

if __name__ == "__main__":
    if args.test:
        print("[app.py] Run Self-Test Successful. Configured options validated.")
        sys.exit(0)
        
    print("============================================================")
    print(f"IndustrialVision AI Server starting on http://{args.host}:{args.port}")
    print("YOLO Deep Learning Support: Dynamic Memory Lazy Loader Active")
    print("============================================================")
    
    app.run(host=args.host, port=args.port, debug=False, threaded=True)
