// IndustrialVision AI Dashboard Application State & Logic

document.addEventListener('DOMContentLoaded', () => {
  
  // ==========================================
  // 1. STATE CONFIGURATION
  // ==========================================
  const state = {
    currentView: 'dashboard',
    activeFeed: 'dock',
    fps: 30,
    confidenceThreshold: 0.85,
    alertCooldown: 10000, // ms
    lastAlertTimes: {}, // key: alertType, value: timestamp
    isStreamPaused: false,
    showHud: true,
    showBoxes: true,
    showSkeleton: true,
    showHeatmap: true,
    
    // Media Source extensions
    activeMediaSource: 'sim', // 'sim', 'webcam', 'industrial', 'video', 'image'
    webcamStream: null,
    uploadedImage: null,
    mousePos: { x: 300, y: 175 }, // To support custom overlay tracking
    
    
    // Core metrics
    metrics: {
      activeWorkers: 12,
      complianceRate: 94.5,
      activeFeedsCount: '4 / 4',
      activeAlertsCount: 0
    },
    
    // Real-time sensor telemetry
    telemetry: {
      temp: 24.2,
      gas: 0.02,
      humidity: 45.8,
      noise: 72.4
    },
    
    // Safety violation logs (active and resolved)
    violations: [],
    
    // Simulation configurations
    zones: {
      dock: {
        name: 'Zone A: Main Loading Dock',
        polygon: [[100, 150], [350, 150], [420, 280], [60, 280]], // Restricted area
        workers: [
          { id: 1, name: 'John D.', x: 120, y: 100, vx: 1, vy: 0.5, size: 24, ppe: { helmet: true, vest: true, goggles: true }, status: 'SECURE' },
          { id: 2, name: 'Loader Operator', x: 450, y: 180, vx: -1.2, vy: 0, size: 28, ppe: { helmet: true, vest: true, goggles: false }, status: 'SECURE' },
          { id: 3, name: 'Visitor M.', x: 80, y: 220, vx: 0.5, vy: -0.2, size: 24, ppe: { helmet: false, vest: true, goggles: false }, status: 'VIOLATION' }
        ],
        gasLevel: 0.02,
        baseNoise: 72
      },
      assembly: {
        name: 'Zone B: Assembly Line B',
        polygon: [[80, 180], [480, 180], [480, 240], [80, 240]], // Conveyor line
        workers: [
          { id: 4, name: 'Alice M.', x: 150, y: 160, vx: 0, vy: 0, size: 24, ppe: { helmet: true, vest: true, goggles: true }, status: 'SECURE' },
          { id: 5, name: 'Bob K.', x: 280, y: 160, vx: 0, vy: 0, size: 24, ppe: { helmet: true, vest: false, goggles: true }, status: 'VIOLATION' },
          { id: 6, name: 'Clara J.', x: 400, y: 160, vx: 0.3, vy: 0.1, size: 24, ppe: { helmet: true, vest: true, goggles: true }, status: 'SECURE' }
        ],
        gasLevel: 0.01,
        baseNoise: 81
      },
      chemical: {
        name: 'Zone C: Chemical Storage',
        polygon: [[150, 100], [330, 100], [330, 220], [150, 220]], // Hazardous chemical vat
        workers: [
          { id: 7, name: 'Tech Rogers', x: 240, y: 250, vx: 0.6, vy: -0.4, size: 24, ppe: { helmet: true, vest: true, goggles: true }, status: 'SECURE' }
        ],
        gasLevel: 0.04,
        baseNoise: 65
      },
      corridor: {
        name: 'Zone D: Warehouse Hallway',
        polygon: [], // No restricted zones here
        workers: [
          { id: 8, name: 'Logistics Courier', x: 50, y: 180, vx: 2, vy: 0, size: 24, ppe: { helmet: true, vest: true, goggles: false }, status: 'SECURE' },
          { id: 9, name: 'Shift Sup.', x: 500, y: 160, vx: -1.5, vy: 0, size: 24, ppe: { helmet: true, vest: true, goggles: true }, status: 'SECURE' }
        ],
        gasLevel: 0.01,
        baseNoise: 68
      }
    }
  };

  // Historical violations categories count
  const historicalViolations = {
    helmet: 18,
    vest: 32,
    goggles: 24,
    intrusion: 12,
    gas: 4
  };

  // ==========================================
  // 2. DOM ELEMENTS
  // ==========================================
  const navItems = document.querySelectorAll('.nav-item');
  const contentViews = document.querySelectorAll('.content-view');
  const viewTitle = document.getElementById('view-title');
  const viewDesc = document.getElementById('view-desc');
  const clockDisplay = document.getElementById('clock-display');
  const bellUnreadDot = document.getElementById('bell-unread-dot');
  
  // Dashboard indicators
  const statActiveWorkers = document.getElementById('stat-active-workers');
  const statComplianceRate = document.getElementById('stat-compliance-rate');
  const statActiveFeeds = document.getElementById('stat-active-feeds');
  const statActiveAlerts = document.getElementById('stat-active-alerts');
  const statAlertsFooterText = document.getElementById('stat-alerts-footer-text');
  const alertMetricCard = document.getElementById('alert-metric-card');
  const systemStatusDot = document.getElementById('system-status-dot');
  const inferenceFps = document.getElementById('inference-fps');

  // Main canvas and overlays
  const mainFeedSelect = document.getElementById('main-feed-select');
  const feedCanvas = document.getElementById('feed-canvas');
  const feedCtx = feedCanvas.getContext('2d');
  const hudAlertTag = document.getElementById('hud-alert-tag');
  const hudAlertText = document.getElementById('hud-alert-text');
  
  // Media source elements
  const sourceBtns = document.querySelectorAll('.source-toolbar .filter-btn');
  const btnSrcVideo = document.getElementById('btn-src-video');
  const btnSrcImage = document.getElementById('btn-src-image');
  const inputVideo = document.getElementById('input-video');
  const inputImage = document.getElementById('input-image');
  const hiddenVideo = document.getElementById('hidden-video');
  
  // Dashboard overlay controls
  const btnToggleHud = document.getElementById('btn-toggle-hud');
  const btnSnapshot = document.getElementById('btn-snapshot');
  const btnPauseStream = document.getElementById('btn-pause-stream');
  
  // Telemetry DOM
  const telTemp = document.getElementById('tel-temp');
  const telGas = document.getElementById('tel-gas');
  const telHumidity = document.getElementById('tel-humidity');
  const telNoise = document.getElementById('tel-noise');
  const telNoiseGlow = document.getElementById('tel-noise-glow');
  
  // Lists & table logs
  const violationsList = document.getElementById('violations-list');
  const emptyAlertsView = document.getElementById('empty-alerts-view');
  const alertsCounter = document.getElementById('alerts-counter');
  const incidentTableBody = document.getElementById('incident-table-body');
  
  // Search & Filter
  const historySearch = document.getElementById('history-search');
  const filterBtns = document.querySelectorAll('.filter-btn');

  // Settings inputs
  const sliderConf = document.getElementById('slider-conf');
  const lblConfThreshold = document.getElementById('lbl-conf-threshold');
  const sliderFps = document.getElementById('slider-fps');
  const lblFramerate = document.getElementById('lbl-framerate');
  const sliderCooldown = document.getElementById('slider-cooldown');
  const lblCooldown = document.getElementById('lbl-cooldown');
  
  const chkHelmet = document.getElementById('chk-helmet');
  const chkVest = document.getElementById('chk-vest');
  const chkGoggles = document.getElementById('chk-goggles');
  const chkZones = document.getElementById('chk-zones');
  
  const diagShowBoxes = document.getElementById('diag-show-boxes');
  const diagShowSkeleton = document.getElementById('diag-show-skeleton');
  const diagShowHeatmap = document.getElementById('diag-show-heatmap');
  
  // Simulation trigger buttons
  const triggerIntrusionBtn = document.getElementById('trigger-intrusion-btn');
  const triggerPpeBtn = document.getElementById('trigger-ppe-btn');
  const triggerGasBtn = document.getElementById('trigger-gas-btn');
  const triggerResetBtn = document.getElementById('trigger-reset-btn');

  // ==========================================
  // 3. CHART CONTROLLERS
  // ==========================================
  let complianceChart = null;
  let violationsChart = null;

  function initCharts() {
    const ctxComp = document.getElementById('complianceChart').getContext('2d');
    const ctxViol = document.getElementById('violationsChart').getContext('2d');

    // Generating initial trend data (slight random walk around 94%)
    const timelineLabels = [];
    const complianceTrend = [];
    const baseHour = new Date().getHours();
    
    for (let i = 23; i >= 0; i--) {
      const h = (baseHour - i + 24) % 24;
      timelineLabels.push(`${h.toString().padStart(2, '0')}:00`);
      
      // Seed a realistic compliance rate curve
      let seedVal = 93.5 + Math.sin(i / 3) * 2 + Math.random() * 1.5;
      if (seedVal > 100) seedVal = 100;
      complianceTrend.push(parseFloat(seedVal.toFixed(1)));
    }

    // Gradient background for Line Chart
    const gradientBlue = ctxComp.createLinearGradient(0, 0, 0, 300);
    gradientBlue.addColorStop(0, 'rgba(6, 182, 212, 0.4)');
    gradientBlue.addColorStop(1, 'rgba(6, 182, 212, 0.0)');

    complianceChart = new Chart(ctxComp, {
      type: 'line',
      data: {
        labels: timelineLabels,
        datasets: [{
          label: 'PPE Compliance Rate (%)',
          data: complianceTrend,
          borderColor: '#06b6d4',
          borderWidth: 3,
          backgroundColor: gradientBlue,
          fill: true,
          tension: 0.35,
          pointBackgroundColor: '#06b6d4',
          pointHoverRadius: 7
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false }
        },
        scales: {
          y: {
            min: 80,
            max: 100,
            grid: { color: 'rgba(255, 255, 255, 0.05)' },
            ticks: { color: '#9ca3af' }
          },
          x: {
            grid: { color: 'rgba(255, 255, 255, 0.05)' },
            ticks: { color: '#9ca3af' }
          }
        }
      }
    });

    violationsChart = new Chart(ctxViol, {
      type: 'bar',
      data: {
        labels: ['No Hard Hat', 'No Safety Vest', 'No Goggles', 'Zone Breach', 'Sensor Leak'],
        datasets: [{
          data: [
            historicalViolations.helmet,
            historicalViolations.vest,
            historicalViolations.goggles,
            historicalViolations.intrusion,
            historicalViolations.gas
          ],
          backgroundColor: [
            'rgba(245, 158, 11, 0.65)',
            'rgba(245, 158, 11, 0.65)',
            'rgba(245, 158, 11, 0.65)',
            'rgba(239, 68, 68, 0.65)',
            'rgba(239, 68, 68, 0.65)'
          ],
          borderColor: [
            '#f59e0b',
            '#f59e0b',
            '#f59e0b',
            '#ef4444',
            '#ef4444'
          ],
          borderWidth: 1.5,
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false }
        },
        scales: {
          y: {
            beginAtZero: true,
            grid: { color: 'rgba(255, 255, 255, 0.05)' },
            ticks: { color: '#9ca3af', stepSize: 5 }
          },
          x: {
            grid: { display: false },
            ticks: { color: '#9ca3af' }
          }
        }
      }
    });
  }

  // Add violation to metrics & update chart
  function updateChartsData(category) {
    if (!violationsChart) return;
    
    let index = 0;
    if (category === 'helmet') { index = 0; historicalViolations.helmet++; }
    else if (category === 'vest') { index = 1; historicalViolations.vest++; }
    else if (category === 'goggles') { index = 2; historicalViolations.goggles++; }
    else if (category === 'intrusion') { index = 3; historicalViolations.intrusion++; }
    else if (category === 'gas') { index = 4; historicalViolations.gas++; }

    violationsChart.data.datasets[0].data[index]++;
    violationsChart.update();

    // Fluctuates line chart downward for alert
    if (complianceChart) {
      const dataLen = complianceChart.data.datasets[0].data.length;
      complianceChart.data.datasets[0].data[dataLen - 1] = Math.max(75, parseFloat((state.metrics.complianceRate - 2.5).toFixed(1)));
      complianceChart.update();
    }
  }

  // ==========================================
  // 4. USER INTERFACE FLOW & NAVIGATION
  // ==========================================
  
  // Handles Switching Tabs
  navItems.forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      
      navItems.forEach(n => n.classList.remove('active'));
      contentViews.forEach(v => v.classList.remove('active'));
      
      item.classList.add('active');
      const targetView = item.getAttribute('data-view');
      state.currentView = targetView;
      
      const targetEl = document.getElementById(`view-${targetView}`);
      if (targetEl) targetEl.classList.add('active');
      
      // Update header headings
      updateHeaderTitles(targetView);
      
      // Trigger canvas sizing when viewing elements
      resizeCanvases();
      
      // Resize charts if opening analytics
      if (targetView === 'analytics') {
        setTimeout(() => {
          complianceChart.resize();
          violationsChart.resize();
        }, 100);
      }
    });
  });

  function updateHeaderTitles(view) {
    const titles = {
      dashboard: { main: 'Command Dashboard', desc: 'Real-time deep learning industrial safety supervisor' },
      streams: { main: 'Multi-Camera Stream Network', desc: 'Live video grids processing worker tracking & safety compliance' },
      analytics: { main: 'Statistical Analytics Dashboard', desc: 'Long-term metric trends, compliance distribution, and hazard logs' },
      history: { main: 'Complete Safety Incident Records', desc: 'Searchable audit trail for industrial safety events & resolutions' },
      settings: { main: 'System Settings & Diagnostics', desc: 'Tune deep learning thresholds, activate safety detectors, and trigger mocks' }
    };
    
    if (titles[view]) {
      viewTitle.textContent = titles[view].main;
      viewDesc.textContent = titles[view].desc;
    }
  }

  // Clock HUD
  function updateClock() {
    const now = new Date();
    clockDisplay.textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) + ' | ' + now.toLocaleDateString([], { month: 'short', day: '2-digit' });
  }
  setInterval(updateClock, 1000);
  updateClock();

  // Switch Main Feed selector
  mainFeedSelect.addEventListener('change', (e) => {
    state.activeFeed = e.target.value;
  });

  // Wire Stream HUD controls
  btnToggleHud.addEventListener('click', () => {
    state.showHud = !state.showHud;
    btnToggleHud.classList.toggle('btn-secondary', !state.showHud);
  });

  btnSnapshot.addEventListener('click', () => {
    showToast('Snapshot Saved', `Visual verification log captured for ${state.zones[state.activeFeed].name}.`, 'warning');
    playSynthesizerTone(800, 0.05);
  });

  btnPauseStream.addEventListener('click', () => {
    state.isStreamPaused = !state.isStreamPaused;
    btnPauseStream.innerHTML = state.isStreamPaused ? '<i data-lucide="play"></i>' : '<i data-lucide="pause"></i>';
    btnPauseStream.classList.toggle('btn-secondary', state.isStreamPaused);
    lucide.createIcons();
  });

  // Settings change hooks
  sliderConf.addEventListener('input', (e) => {
    state.confidenceThreshold = e.target.value / 100;
    lblConfThreshold.textContent = `${e.target.value}%`;
  });

  sliderFps.addEventListener('input', (e) => {
    state.fps = parseInt(e.target.value);
    lblFramerate.textContent = `${e.target.value} FPS`;
    inferenceFps.textContent = `${(state.fps - 0.6 + Math.random()*1.2).toFixed(1)} FPS`;
  });

  sliderCooldown.addEventListener('input', (e) => {
    state.alertCooldown = e.target.value * 1000;
    lblCooldown.textContent = `${e.target.value}s`;
  });

  // Diagnostic switches
  diagShowBoxes.addEventListener('change', (e) => state.showBoxes = e.target.checked);
  diagShowSkeleton.addEventListener('change', (e) => state.showSkeleton = e.target.checked);
  diagShowHeatmap.addEventListener('change', (e) => state.showHeatmap = e.target.checked);

  // Monitor links from multi-stream feeds
  document.querySelectorAll('.select-camera-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const camVal = btn.getAttribute('data-cam-val');
      state.activeFeed = camVal;
      mainFeedSelect.value = camVal;
      
      // Go to Dashboard
      // Go to Dashboard
      document.querySelector('[data-view="dashboard"]').click();
    });
  });

  // ==========================================
  // 4B. MEDIA SOURCE MANAGEMENT
  // ==========================================

  function stopActiveStreams() {
    if (state.webcamStream) {
      state.webcamStream.getTracks().forEach(track => track.stop());
      state.webcamStream = null;
    }
    hiddenVideo.pause();
    hiddenVideo.src = '';
    hiddenVideo.srcObject = null;
    state.uploadedImage = null;
  }

  async function startWebcam() {
    try {
      stopActiveStreams();
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: 640, height: 360 } 
      });
      state.webcamStream = stream;
      hiddenVideo.srcObject = stream;
      hiddenVideo.onloadedmetadata = () => {
        hiddenVideo.play().catch(e => console.error("Video play failed:", e));
      };
      state.activeMediaSource = 'webcam';
      showToast('Camera Connected', 'Laptop camera feed successfully loaded.', 'warning');
    } catch (e) {
      console.error("Error starting webcam:", e);
      showToast('Camera Error', 'Unable to access laptop webcam. Verify permissions.', 'danger');
      // Reset back to Sim button
      document.querySelector('[data-source="sim"]').click();
    }
  }

  // Handle clicking source toggles
  sourceBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      
      const source = btn.getAttribute('data-source') || btn.id;
      
      // If we clicked a button that triggers file explorer, don't set active button state yet
      if (source === 'btn-src-video' || source === 'btn-src-image') {
        if (source === 'btn-src-video') inputVideo.click();
        if (source === 'btn-src-image') inputImage.click();
        return;
      }

      // Update button selection style
      sourceBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      if (source === 'sim') {
        stopActiveStreams();
        state.activeMediaSource = 'sim';
        mainFeedSelect.style.display = 'block';
        showToast('Source Swapped', 'Running synthetic deep learning environment simulation.', 'warning');
      } else if (source === 'webcam') {
        mainFeedSelect.style.display = 'none';
        startWebcam();
      } else if (source === 'industrial') {
        stopActiveStreams();
        state.activeMediaSource = 'industrial';
        mainFeedSelect.style.display = 'block';
        showToast('Source Swapped', 'Switched to simulated high-fidelity Industrial CCTV.', 'warning');
      }
    });
  });

  // File Upload Handlers
  inputVideo.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;

    stopActiveStreams();
    const fileURL = URL.createObjectURL(file);
    hiddenVideo.src = fileURL;
    hiddenVideo.onloadedmetadata = () => {
      hiddenVideo.play().catch(ex => console.error(ex));
    };
    
    state.activeMediaSource = 'video';
    
    // Set active button UI
    sourceBtns.forEach(b => b.classList.remove('active'));
    btnSrcVideo.classList.add('active');
    mainFeedSelect.style.display = 'none';
    
    showToast('Video Stream Loaded', `Scanning file: ${file.name}`, 'warning');
  });

  inputImage.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;

    stopActiveStreams();
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        state.uploadedImage = img;
        state.activeMediaSource = 'image';
        
        // Set active button UI
        sourceBtns.forEach(b => b.classList.remove('active'));
        btnSrcImage.classList.add('active');
        mainFeedSelect.style.display = 'none';
        
        showToast('Image Loaded', `Analyzing static frames: ${file.name}`, 'warning');
      };
      img.src = event.target.result;
    };
    reader.readAsDataURL(file);
  });

  // Optional cursor target tracking overlay on Hover
  feedCanvas.addEventListener('mousemove', (e) => {
    const rect = feedCanvas.getBoundingClientRect();
    state.mousePos.x = (e.clientX - rect.left) * (600 / rect.width);
    state.mousePos.y = (e.clientY - rect.top) * (350 / rect.height);
  });

  // ==========================================
  // 5. SYNTHESIZER BEIPS (Web Audio API)
  // ==========================================
  function playSynthesizerTone(frequency, duration, type = 'sine') {
    try {
      const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      
      oscillator.type = type;
      oscillator.frequency.value = frequency;
      
      gainNode.gain.setValueAtTime(0.08, audioCtx.currentTime);
      // Fade out
      gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
      
      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      
      oscillator.start();
      oscillator.stop(audioCtx.currentTime + duration);
    } catch (e) {
      console.warn("Web Audio API not supported or user gesture needed: ", e);
    }
  }

  // ==========================================
  // 6. TOAST NOTIFICATIONS & DISPATCH
  // ==========================================
  const toastContainer = document.getElementById('toast-container');

  function showToast(title, desc, severity = 'danger') {
    const toast = document.createElement('div');
    toast.className = `toast ${severity === 'warning' ? 'toast-warning' : ''}`;
    
    const iconType = severity === 'danger' ? 'alert-octagon' : 'alert-triangle';
    
    toast.innerHTML = `
      <i data-lucide="${iconType}" style="width: 24px; height: 24px; color: ${severity === 'danger' ? 'var(--color-danger)' : 'var(--color-warning)'}; flex-shrink:0;"></i>
      <div class="toast-body">
        <div class="toast-title">${title}</div>
        <div class="toast-desc">${desc}</div>
      </div>
    `;
    
    toastContainer.appendChild(toast);
    lucide.createIcons();
    
    // Play hazard alarm sound pattern
    if (severity === 'danger') {
      playSynthesizerTone(440, 0.2, 'sawtooth');
      setTimeout(() => playSynthesizerTone(440, 0.2, 'sawtooth'), 250);
      bellUnreadDot.style.display = 'block';
    } else {
      playSynthesizerTone(550, 0.15, 'triangle');
    }
    
    // Auto remove
    setTimeout(() => {
      toast.style.animation = 'slide-in 0.3s reverse forwards';
      setTimeout(() => {
        if (toast.parentNode === toastContainer) {
          toastContainer.removeChild(toast);
        }
      }, 300);
    }, 4500);
  }

  // Triggering visual alert bells
  document.getElementById('header-alert-bell').addEventListener('click', () => {
    bellUnreadDot.style.display = 'none';
    showToast('Info Panel', 'All high-priority alerts logged into incident table.', 'warning');
  });

  // ==========================================
  // 7. ALERT EVENT MANAGER
  // ==========================================
  
  function triggerViolationEvent(zoneKey, classType, msg, severity = 'danger') {
    const now = Date.now();
    const alertKey = `${zoneKey}_${classType}`;
    
    // Check cooldown
    if (state.lastAlertTimes[alertKey] && (now - state.lastAlertTimes[alertKey] < state.alertCooldown)) {
      return; // Under cooldown
    }
    
    state.lastAlertTimes[alertKey] = now;
    
    // Generate incident record
    const date = new Date();
    const timestampStr = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    
    const violation = {
      id: Date.now() + Math.random().toString(36).substr(2, 5),
      timestamp: timestampStr,
      rawTimestamp: date,
      zone: zoneKey,
      zoneName: state.zones[zoneKey].name,
      classType: classType,
      message: msg,
      severity: severity,
      status: 'unresolved'
    };

    // Add to state list (prepend)
    state.violations.unshift(violation);
    
    // Increment specific stats
    updateChartsData(classType);

    // Dynamic UI Update
    renderViolationsList();
    renderIncidentTable();
    updateGeneralStats();
    
    // Raise HUD indicator if currently viewing the zone
    if (state.activeFeed === zoneKey) {
      hudAlertTag.style.display = 'flex';
      hudAlertText.textContent = msg.toUpperCase();
      setTimeout(() => {
        if (hudAlertText.textContent === msg.toUpperCase()) {
          hudAlertTag.style.display = 'none';
        }
      }, 5000);
    }
    
    // Trigger desktop overlay toast
    showToast(`AI ALERT: ${msg}`, `Zone monitor detected critical anomaly in ${state.zones[zoneKey].name}`, severity);
  }

  function resolveViolation(id) {
    const violationIndex = state.violations.findIndex(v => v.id === id);
    if (violationIndex !== -1) {
      state.violations[violationIndex].status = 'resolved';
      
      playSynthesizerTone(600, 0.08);
      renderViolationsList();
      renderIncidentTable();
      updateGeneralStats();
    }
  }

  function renderViolationsList() {
    // Clear list
    violationsList.innerHTML = '';
    const unresolvedViolations = state.violations.filter(v => v.status === 'unresolved');
    
    if (unresolvedViolations.length === 0) {
      violationsList.appendChild(emptyAlertsView);
      alertsCounter.textContent = '0 Active';
      return;
    }
    
    alertsCounter.textContent = `${unresolvedViolations.length} Active`;
    
    unresolvedViolations.forEach(v => {
      const item = document.createElement('div');
      item.className = 'violation-item unresolved';
      
      const badgeClass = v.severity === 'danger' ? 'badge-danger' : 'badge-warning';
      const icon = v.severity === 'danger' ? 'alert-octagon' : 'alert-triangle';
      
      item.innerHTML = `
        <div class="v-icon-box ${v.severity}">
          <i data-lucide="${icon}"></i>
        </div>
        <div class="v-details">
          <div class="v-title">${v.message}</div>
          <div style="font-size:11px; color: var(--text-muted); margin-top:2px;">
            ${v.zoneName}
          </div>
          <div class="v-meta">
            <span style="font-family: var(--font-mono);">${v.timestamp}</span>
            <span class="v-badge ${badgeClass}">${v.severity}</span>
          </div>
        </div>
        <div style="display: flex; flex-direction: column; gap: 4px; align-self: center;">
          <button class="btn btn-secondary btn-sm resolve-btn" style="padding: 4px 8px; font-size:10px;" data-id="${v.id}">
            Clear
          </button>
          <button class="btn btn-secondary btn-sm verify-btn" style="padding: 4px 8px; font-size:10px; display: flex; align-items: center; gap: 4px;" data-id="${v.id}">
            <i data-lucide="upload" style="width: 10px; height: 10px;"></i> Verify
          </button>
        </div>
      `;
      
      violationsList.appendChild(item);
    });
    
    // Attach listener for resolve button
    document.querySelectorAll('.resolve-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        resolveViolation(btn.getAttribute('data-id'));
      });
    });

    // Attach listener for verify button
    document.querySelectorAll('.verify-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        state.activeVerificationId = btn.getAttribute('data-id');
        document.getElementById('verification-upload-input').click();
      });
    });
    
    lucide.createIcons();
  }

  function renderIncidentTable() {
    incidentTableBody.innerHTML = '';
    
    let filtered = state.violations;
    
    // Filter tags logic
    const activeFilterBtn = document.querySelector('.filter-btn.active');
    const filterType = activeFilterBtn ? activeFilterBtn.getAttribute('data-filter') : 'all';
    
    if (filterType === 'danger') {
      filtered = filtered.filter(v => v.severity === 'danger');
    } else if (filterType === 'warning') {
      filtered = filtered.filter(v => v.severity === 'warning');
    } else if (filterType === 'resolved') {
      filtered = filtered.filter(v => v.status === 'resolved');
    }
    
    // Search input query
    const query = historySearch.value.trim().toLowerCase();
    if (query !== '') {
      filtered = filtered.filter(v => {
        return v.message.toLowerCase().includes(query) || 
               v.zoneName.toLowerCase().includes(query) ||
               v.classType.toLowerCase().includes(query);
      });
    }
    
    if (filtered.length === 0) {
      incidentTableBody.innerHTML = `
        <tr>
          <td colspan="6" style="text-align: center; color: var(--text-muted); padding: 30px;">
            No historical logs fit this filter criteria.
          </td>
        </tr>
      `;
      return;
    }
    
    filtered.forEach(v => {
      const tr = document.createElement('tr');
      
      const badgeSev = v.severity === 'danger' 
        ? `<span class="v-badge badge-danger" style="padding:3px 8px;">DANGER</span>`
        : `<span class="v-badge badge-warning" style="padding:3px 8px;">WARNING</span>`;
        
      const statusMarkup = v.status === 'unresolved'
        ? `<span style="color: var(--color-danger); font-weight:700;"><i data-lucide="clock" style="width:12px; height:12px; display:inline-block; vertical-align:-2px; margin-right:4px;"></i>Unresolved</span>`
        : `<span style="color: var(--color-success); font-weight:700;"><i data-lucide="check-circle" style="width:12px; height:12px; display:inline-block; vertical-align:-2px; margin-right:4px;"></i>Cleared</span>`;
        
      const actionMarkup = v.status === 'unresolved'
        ? `<div style="display: flex; gap: 6px;">
            <button class="btn btn-secondary btn-sm resolve-table-btn" style="padding:6px 10px; font-size:11px;" data-id="${v.id}">Clear</button>
            <button class="btn btn-secondary btn-sm verify-table-btn" style="padding:6px 10px; font-size:11px; display: flex; align-items: center; gap: 4px;" data-id="${v.id}">
              <i data-lucide="upload" style="width: 12px; height: 12px;"></i> Verify
            </button>
          </div>`
        : (v.evidenceFile 
            ? `<div style="display: flex; flex-direction: column; gap: 2px;">
                <span style="color: var(--text-muted); font-size: 11px;">Verified & Closed</span>
                <span style="color: var(--color-primary); font-size: 11px; display: flex; align-items: center; gap: 4px; font-family: var(--font-mono); font-weight:700;"><i data-lucide="paperclip" style="width:11px; height:11px;"></i> ${v.evidenceFile}</span>
               </div>`
            : `<span style="color: var(--text-muted); font-size: 12px;">Logged by Edge Engine</span>`);

      tr.innerHTML = `
        <td style="font-family: var(--font-mono); font-size:13px;">${v.rawTimestamp.toLocaleString()}</td>
        <td style="font-weight:600;">${v.zoneName}</td>
        <td>
          <div style="font-weight:700; font-size:13px;">${v.message}</div>
          <div style="font-size:11px; color: var(--text-muted); margin-top:2px;">Network: YOLOv8-Safety-X</div>
        </td>
        <td>${badgeSev}</td>
        <td>${statusMarkup}</td>
        <td>${actionMarkup}</td>
      `;
      
      incidentTableBody.appendChild(tr);
    });
    
    // Attach table action hooks
    document.querySelectorAll('.resolve-table-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        resolveViolation(btn.getAttribute('data-id'));
      });
    });

    document.querySelectorAll('.verify-table-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        state.activeVerificationId = btn.getAttribute('data-id');
        document.getElementById('verification-upload-input').click();
      });
    });
    
    lucide.createIcons();
  }

  // Trigger search on typing
  historySearch.addEventListener('input', renderIncidentTable);

  // Trigger filter tag click
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderIncidentTable();
    });
  });

  // ==========================================
  // 8. GENERAL METRIC CARD RE-COMPUTATIONS
  // ==========================================
  function updateGeneralStats() {
    const activeViolationsCount = state.violations.filter(v => v.status === 'unresolved').length;
    state.metrics.activeAlertsCount = activeViolationsCount;
    statActiveAlerts.textContent = activeViolationsCount;
    
    // Recalc compliance rates
    if (activeViolationsCount > 0) {
      state.metrics.complianceRate = Math.max(76.2, parseFloat((95.5 - (activeViolationsCount * 4.5)).toFixed(1)));
      statComplianceRate.textContent = `${state.metrics.complianceRate}%`;
      statComplianceRate.className = 'metric-value danger';
      
      alertMetricCard.style.borderColor = 'rgba(239, 68, 68, 0.4)';
      alertMetricCard.style.boxShadow = '0 0 15px rgba(239, 68, 68, 0.15)';
      statAlertsFooterText.textContent = `${activeViolationsCount} unsafe condition(s) detected`;
      statAlertsFooterText.style.color = 'var(--color-danger)';
      
      systemStatusDot.className = 'status-dot danger';
    } else {
      state.metrics.complianceRate = 96.8;
      statComplianceRate.textContent = `${state.metrics.complianceRate}%`;
      statComplianceRate.className = 'metric-value success';
      
      alertMetricCard.style.borderColor = 'var(--border-color)';
      alertMetricCard.style.boxShadow = 'var(--card-shadow)';
      statAlertsFooterText.textContent = 'No active violations detected';
      statAlertsFooterText.style.color = 'var(--text-muted)';
      
      systemStatusDot.className = 'status-dot';
    }

    // Update individual analytics cards
    const zones = ['dock', 'assembly', 'chemical', 'corridor'];
    zones.forEach(zk => {
      const zone = state.zones[zk];
      const warningsEl = document.getElementById(`an-warnings-${zk}`);
      const complianceEl = document.getElementById(`an-compliance-${zk}`);
      const badgeEl = document.getElementById(`badge-cam-${zk}`);
      
      const zoneAlerts = state.violations.filter(v => v.zone === zk && v.status === 'unresolved');
      
      if (warningsEl) warningsEl.textContent = zoneAlerts.length;
      
      let complianceScore = 100;
      if (zoneAlerts.length > 0) {
        complianceScore = Math.max(60, 100 - (zoneAlerts.length * 20));
      }
      
      if (complianceEl) {
        complianceEl.textContent = `${complianceScore}%`;
        complianceEl.style.color = complianceScore < 90 ? 'var(--color-danger)' : 'var(--color-success)';
      }

      if (badgeEl) {
        if (zoneAlerts.length > 0) {
          badgeEl.textContent = 'WARNING';
          badgeEl.style.backgroundColor = 'var(--color-danger)';
        } else {
          badgeEl.textContent = 'SECURE';
          badgeEl.style.backgroundColor = 'var(--color-success)';
        }
      }
    });
  }

  // ==========================================
  // 9. TELEMETRY NOISE GENERATOR (Sensor Simulation)
  // ==========================================
  function simulateTelemetryFluctuations() {
    // Ambient noise & values walks
    state.telemetry.temp = parseFloat((state.telemetry.temp + (Math.random() - 0.5) * 0.1).toFixed(1));
    state.telemetry.humidity = parseFloat((state.telemetry.humidity + (Math.random() - 0.5) * 0.2).toFixed(1));
    
    // Gas sensors
    const chemicalAlerts = state.violations.filter(v => v.zone === 'chemical' && v.classType === 'gas' && v.status === 'unresolved');
    if (chemicalAlerts.length > 0) {
      state.telemetry.gas = parseFloat((state.telemetry.gas + Math.random() * 2 + 0.5).toFixed(2));
      if (state.telemetry.gas > 12.5) state.telemetry.gas = 12.5; // Cap toxic levels
    } else {
      state.telemetry.gas = parseFloat(Math.max(0.01, (state.telemetry.gas - 0.05 + Math.random() * 0.04)).toFixed(2));
    }
    
    // Ambient noise decibels
    let baseNoiseLevel = state.zones[state.activeFeed].baseNoise;
    state.telemetry.noise = parseFloat((baseNoiseLevel + Math.sin(Date.now() / 2000) * 2 + Math.random() * 1.5).toFixed(1));
    
    // Update dashboard HTML
    telTemp.textContent = `${state.telemetry.temp} °C`;
    telGas.textContent = `${state.telemetry.gas} ppm`;
    telHumidity.textContent = `${state.telemetry.humidity}%`;
    telNoise.textContent = `${state.telemetry.noise} dBA`;
    
    if (state.telemetry.noise > 82) {
      telNoiseGlow.className = 'telemetry-circle warning-glow';
    } else {
      telNoiseGlow.className = 'telemetry-circle cyan-glow';
    }
  }
  setInterval(simulateTelemetryFluctuations, 1500);

  // ==========================================
  // 10. SIMULATOR TRIGGERS (Settings View Actions)
  // ==========================================
  
  triggerIntrusionBtn.addEventListener('click', () => {
    // Force a worker to move directly into restricted zone
    const dockZone = state.zones.dock;
    const intruder = dockZone.workers.find(w => w.id === 3);
    if (intruder) {
      intruder.x = 220; // Coordinates inside the Loading Dock polygon
      intruder.y = 200;
    }
    showToast('Simulation Command Dispatch', 'Worker 3 coordinates injected inside Safe perimeter boundary.', 'warning');
  });

  triggerPpeBtn.addEventListener('click', () => {
    // Remove safety helmet from assembly line worker
    const worker = state.zones.assembly.workers.find(w => w.id === 4);
    if (worker) {
      worker.ppe.helmet = false;
      worker.ppe.vest = false;
    }
    showToast('PPE Breach Injector', 'Simulated helmet and high-vis vest detachment command.', 'warning');
  });

  triggerGasBtn.addEventListener('click', () => {
    triggerViolationEvent('chemical', 'gas', 'Hazardous H2S Gas Leak Detected', 'danger');
  });

  triggerResetBtn.addEventListener('click', () => {
    // Clear all violations
    state.violations = [];
    state.lastAlertTimes = {};
    
    // Reset worker positions and states
    // Dock
    state.zones.dock.workers[2].x = 80;
    state.zones.dock.workers[2].y = 220;
    state.zones.dock.workers[2].ppe.helmet = true;
    
    // Assembly
    state.zones.assembly.workers[0].ppe.helmet = true;
    state.zones.assembly.workers[0].ppe.vest = true;
    state.zones.assembly.workers[1].ppe.vest = true;
    
    state.telemetry.gas = 0.02;
    hudAlertTag.style.display = 'none';

    renderViolationsList();
    renderIncidentTable();
    updateGeneralStats();
    showToast('System Override', 'Inference logs cleared and simulated coordinates reset.', 'warning');
  });

  // ==========================================
  // 11. WEB CANVAS-BASED COMPUTER VISION GENERATOR
  // ==========================================
  
  function resizeCanvases() {
    // Standard size coordinates
    feedCanvas.width = feedCanvas.offsetWidth;
    feedCanvas.height = feedCanvas.offsetHeight;
  }
  window.addEventListener('resize', resizeCanvases);
  
  // Custom camera specific canvas containers for Streams grid
  const streamCanvases = {
    dock: { el: document.getElementById('canvas-cam-dock'), ctx: document.getElementById('canvas-cam-dock').getContext('2d') },
    assembly: { el: document.getElementById('canvas-cam-assembly'), ctx: document.getElementById('canvas-cam-assembly').getContext('2d') },
    chemical: { el: document.getElementById('canvas-cam-chemical'), ctx: document.getElementById('canvas-cam-chemical').getContext('2d') },
    corridor: { el: document.getElementById('canvas-cam-corridor'), ctx: document.getElementById('canvas-cam-corridor').getContext('2d') }
  };

  function setupStreamGridSizing() {
    for (const key in streamCanvases) {
      const c = streamCanvases[key];
      c.el.width = c.el.offsetWidth;
      c.el.height = c.el.offsetHeight;
    }
  }

  // Draw simulated frames
  function drawStreamSimulation(ctx, canvasEl, zoneKey) {
    const width = canvasEl.width;
    const height = canvasEl.height;
    const zone = state.zones[zoneKey];
    
    if (!zone) return;
    
    // 1. Draw static grid industrial background
    ctx.fillStyle = '#0a0d17';
    ctx.fillRect(0, 0, width, height);
    
    // Scale coordinate helper
    const scaleX = width / 600;
    const scaleY = height / 350;

    // Draw structural floor layout
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
    ctx.lineWidth = 1;
    for (let i = 0; i < width; i += 30) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, height);
      ctx.stroke();
    }
    for (let i = 0; i < height; i += 30) {
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(width, i);
      ctx.stroke();
    }
    
    // 2. Draw restricted boundary safety polygons
    if (state.showHeatmap && zone.polygon.length > 0) {
      ctx.beginPath();
      ctx.moveTo(zone.polygon[0][0] * scaleX, zone.polygon[0][1] * scaleY);
      for (let i = 1; i < zone.polygon.length; i++) {
        ctx.lineTo(zone.polygon[i][0] * scaleX, zone.polygon[i][1] * scaleY);
      }
      ctx.closePath();
      
      const activeBreach = state.violations.some(v => v.zone === zoneKey && v.classType === 'intrusion' && v.status === 'unresolved');
      
      if (activeBreach) {
        ctx.fillStyle = 'rgba(239, 68, 68, 0.15)';
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.7)';
        ctx.lineWidth = 2 + Math.sin(Date.now() / 200) * 0.5;
      } else {
        ctx.fillStyle = 'rgba(245, 158, 11, 0.06)';
        ctx.strokeStyle = 'rgba(245, 158, 11, 0.4)';
        ctx.lineWidth = 1.5;
      }
      ctx.fill();
      ctx.stroke();
      
      // Draw perimeter labels
      ctx.fillStyle = activeBreach ? '#ef4444' : '#f59e0b';
      ctx.font = `bold ${Math.round(10 * scaleX)}px ${state.showBoxes ? 'var(--font-mono)' : 'var(--font-main)'}`;
      ctx.fillText(activeBreach ? 'BREACH: FORKLIFT ZONE' : 'HAZARDOUS FORKLIFT ZONE', zone.polygon[0][0]*scaleX, (zone.polygon[0][1] - 5)*scaleY);
    }

    // 3. Draw simulated industrial scenery
    if (zoneKey === 'dock') {
      // Forklift box representation
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(400 * scaleX, 100 * scaleY, 80 * scaleX, 60 * scaleY);
      ctx.strokeStyle = 'rgba(255,255,255,0.1)';
      ctx.strokeRect(400 * scaleX, 100 * scaleY, 80 * scaleX, 60 * scaleY);
      ctx.fillStyle = '#e2e8f0';
      ctx.font = '10px sans-serif';
      ctx.fillText('BAY 01 CARGO', 405 * scaleX, 120 * scaleY);
    } else if (zoneKey === 'assembly') {
      // Draw conveyor belt lines
      ctx.fillStyle = 'rgba(59, 130, 246, 0.05)';
      ctx.fillRect(80 * scaleX, 180 * scaleY, 400 * scaleX, 60 * scaleY);
      ctx.strokeStyle = 'rgba(59, 130, 246, 0.3)';
      ctx.lineWidth = 2;
      ctx.strokeRect(80 * scaleX, 180 * scaleY, 400 * scaleX, 60 * scaleY);
      
      ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
      for (let offset = 0; offset < 400; offset += 40) {
        ctx.fillRect((85 + offset) * scaleX, 185 * scaleY, 15 * scaleX, 50 * scaleY);
      }
    } else if (zoneKey === 'chemical') {
      // Draw chemical storage vats
      ctx.fillStyle = '#1e1b4b';
      ctx.beginPath();
      ctx.arc(240 * scaleX, 160 * scaleY, 40 * scaleX, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = 'rgba(6, 182, 212, 0.4)';
      ctx.stroke();
      
      ctx.fillStyle = '#06b6d4';
      ctx.font = '10px sans-serif';
      ctx.fillText('TANK 09 (ACID)', 200 * scaleX, 163 * scaleY);
    }

    // 4. Update and Draw Workers
    zone.workers.forEach(w => {
      // Update coordinates (mock walking animation)
      if (!state.isStreamPaused) {
        w.x += w.vx;
        w.y += w.vy;
        
        // Boundaries bounce
        if (w.x - w.size < 0 || w.x + w.size > 600) w.vx *= -1;
        if (w.y - w.size < 40 || w.y + w.size > 320) w.vy *= -1;
      }
      
      const rx = w.x * scaleX;
      const ry = w.y * scaleY;
      
      // Draw simple worker symbol (dot with helmet/vest indicator lines)
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.arc(rx, ry, w.size * scaleX, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#475569';
      ctx.stroke();

      // Check restricted zone overlap
      if (zone.polygon.length > 0 && chkZones.checked) {
        const inPolygon = isPointInPolygon([w.x, w.y], zone.polygon);
        if (inPolygon) {
          triggerViolationEvent(zoneKey, 'intrusion', `Restricted Area Breach: Forklift zone`, 'danger');
        }
      }

      // Check PPE Violations
      if (!w.ppe.helmet && chkHelmet.checked) {
        triggerViolationEvent(zoneKey, 'helmet', `Missing PPE: Safety Helmet Violation`, 'warning');
      }
      if (!w.ppe.vest && chkVest.checked) {
        triggerViolationEvent(zoneKey, 'vest', `Missing PPE: Safety Vest Violation`, 'warning');
      }
      
      // Render body coordinates skeleton
      if (state.showSkeleton) {
        ctx.strokeStyle = 'rgba(16, 185, 129, 0.7)';
        ctx.lineWidth = 1.5;
        
        // Simple stick figure bones
        ctx.beginPath();
        // Spine
        ctx.moveTo(rx, ry - 15 * scaleY);
        ctx.lineTo(rx, ry + 15 * scaleY);
        // Arms
        ctx.moveTo(rx - 12 * scaleX, ry - 5 * scaleY);
        ctx.lineTo(rx + 12 * scaleX, ry - 5 * scaleY);
        // Legs
        ctx.moveTo(rx, ry + 15 * scaleY);
        ctx.lineTo(rx - 8 * scaleX, ry + 30 * scaleY);
        ctx.moveTo(rx, ry + 15 * scaleY);
        ctx.lineTo(rx + 8 * scaleX, ry + 30 * scaleY);
        ctx.stroke();

        // Joint dots
        ctx.fillStyle = 'rgba(6, 182, 212, 1)';
        const joints = [[rx, ry - 15 * scaleY], [rx - 12 * scaleX, ry - 5 * scaleY], [rx + 12 * scaleX, ry - 5 * scaleY], [rx, ry + 15 * scaleY]];
        joints.forEach(j => {
          ctx.beginPath();
          ctx.arc(j[0], j[1], 2, 0, Math.PI * 2);
          ctx.fill();
        });
      }

      // Render AI Object detection Bounding Boxes
      if (state.showBoxes) {
        // Find if this worker has unresolved violations
        const hasHelmetViolation = !w.ppe.helmet && chkHelmet.checked;
        const hasVestViolation = !w.ppe.vest && chkVest.checked;
        
        const boxColor = (hasHelmetViolation || hasVestViolation) ? '#ef4444' : '#10b981';
        
        ctx.strokeStyle = boxColor;
        ctx.lineWidth = 2;
        const boxWidth = w.size * 2.2 * scaleX;
        const boxHeight = w.size * 3.4 * scaleY;
        ctx.strokeRect(rx - boxWidth/2, ry - boxHeight * 0.45, boxWidth, boxHeight);
        
        // Class tag banner
        ctx.fillStyle = boxColor;
        ctx.fillRect(rx - boxWidth/2, ry - boxHeight * 0.45 - 16 * scaleY, boxWidth, 16 * scaleY);
        
        ctx.fillStyle = '#ffffff';
        ctx.font = `bold ${Math.round(8 * scaleX)}px var(--font-mono)`;
        
        const tagText = (hasHelmetViolation || hasVestViolation) ? 'VIOLATION' : 'WORKER OK';
        ctx.fillText(`${tagText} ${(state.confidenceThreshold + Math.random()*0.1).toFixed(2)}`, rx - boxWidth/2 + 4, ry - boxHeight * 0.45 - 4);

        // Draw sub boxes (Helmet and Vest)
        if (w.ppe.helmet && chkHelmet.checked) {
          ctx.strokeStyle = '#10b981';
          ctx.lineWidth = 1;
          ctx.strokeRect(rx - 8*scaleX, ry - boxHeight * 0.45 + 2*scaleY, 16*scaleX, 10*scaleY);
        } else if (chkHelmet.checked) {
          ctx.strokeStyle = '#ef4444';
          ctx.setLineDash([2, 2]);
          ctx.strokeRect(rx - 8*scaleX, ry - boxHeight * 0.45 + 2*scaleY, 16*scaleX, 10*scaleY);
          ctx.setLineDash([]);
        }
      }
    });

    // 5. Digital camera laser sweep animation line
    if (!state.isStreamPaused) {
      const sweepY = (Date.now() / 15) % height;
      ctx.strokeStyle = 'rgba(6, 182, 212, 0.12)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, sweepY);
      ctx.lineTo(width, sweepY);
      ctx.stroke();
    }

    // 6. Industrial night-vision/thermal styling filters
    if (state.activeMediaSource === 'industrial') {
      // Draw green-colored night-vision overlay
      ctx.fillStyle = 'rgba(0, 255, 64, 0.08)';
      ctx.fillRect(0, 0, width, height);

      // Diagnostic details text
      ctx.fillStyle = '#00ff44';
      ctx.font = `bold ${Math.round(9 * scaleX)}px var(--font-mono)`;
      ctx.fillText("CAM 01 // OVERHEAD DETECTOR", 15 * scaleX, 22 * scaleY);
      ctx.fillText("THERMAL GAIN: ISO_AUTO", 15 * scaleX, 36 * scaleY);
      ctx.fillText("MODE: INDUSTRIAL CCTV_NIGHT", width - 170 * scaleX, 22 * scaleY);
      ctx.fillText(`FPS: ${(state.fps - 0.5 + Math.random()).toFixed(1)}`, width - 50 * scaleX, 36 * scaleY);

      // Custom visual grid lines/crosshairs
      ctx.strokeStyle = 'rgba(0, 255, 64, 0.2)';
      ctx.lineWidth = 1;
      
      // Center crosshair
      ctx.beginPath();
      ctx.moveTo(width/2 - 15, height/2); ctx.lineTo(width/2 + 15, height/2);
      ctx.moveTo(width/2, height/2 - 15); ctx.lineTo(width/2, height/2 + 15);
      ctx.stroke();
      
      // Corner brackets
      const bSz = 16;
      ctx.beginPath();
      ctx.moveTo(10, 10 + bSz); ctx.lineTo(10, 10); ctx.lineTo(10 + bSz, 10);
      ctx.moveTo(width - 10 - bSz, 10); ctx.lineTo(width - 10, 10); ctx.lineTo(width - 10, 10 + bSz);
      ctx.moveTo(10, height - 10 - bSz); ctx.lineTo(10, height - 10); ctx.lineTo(10 + bSz, height - 10);
      ctx.moveTo(width - 10 - bSz, height - 10); ctx.lineTo(width - 10, height - 10); ctx.lineTo(width - 10, height - 10 - bSz);
      ctx.stroke();
    }
  }

  // Draws simulated YOLO bounding boxes on uploaded media/camera
  function drawMediaDetectorOverlay(ctx, width, height) {
    const scaleX = width / 600;
    const scaleY = height / 350;

    // Laser scan sweep
    if (!state.isStreamPaused) {
      const sweepY = (Date.now() / 15) % height;
      ctx.strokeStyle = 'rgba(6, 182, 212, 0.25)';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(0, sweepY);
      ctx.lineTo(width, sweepY);
      ctx.stroke();
    }

    if (state.activeMediaSource === 'webcam') {
      // 1. Mouse-following tracked worker box (interactive)
      const mx = state.mousePos.x * scaleX;
      const my = state.mousePos.y * scaleY;
      
      // Draw detection box
      const boxW = 80 * scaleX;
      const boxH = 150 * scaleY;
      
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 2;
      ctx.strokeRect(mx - boxW/2, my - boxH/2, boxW, boxH);
      
      // Tag
      ctx.fillStyle = '#10b981';
      ctx.fillRect(mx - boxW/2, my - boxH/2 - 16*scaleY, boxW, 16*scaleY);
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold ${Math.round(8*scaleX)}px var(--font-mono)`;
      ctx.fillText(`OPERATOR OK ${state.confidenceThreshold.toFixed(2)}`, mx - boxW/2 + 4, my - boxH/2 - 5*scaleY);

      // Goggles check
      if (chkGoggles.checked) {
        ctx.strokeStyle = '#10b981';
        ctx.lineWidth = 1;
        ctx.strokeRect(mx - 10*scaleX, my - boxH/2 + 20*scaleY, 20*scaleX, 8*scaleY);
      }

      // Helmet check
      if (chkHelmet.checked) {
        ctx.strokeStyle = '#10b981';
        ctx.lineWidth = 1;
        ctx.strokeRect(mx - 15*scaleX, my - boxH/2 + 2*scaleY, 30*scaleX, 10*scaleY);
      }

      // 2. Draw pose estimation skeletons
      if (state.showSkeleton) {
        ctx.strokeStyle = 'rgba(6, 182, 212, 0.8)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        // Spine
        ctx.moveTo(mx, my - 20*scaleY); ctx.lineTo(mx, my + 15*scaleY);
        // Shoulders
        ctx.moveTo(mx - 24*scaleX, my - 10*scaleY); ctx.lineTo(mx + 24*scaleX, my - 10*scaleY);
        // Arms
        ctx.lineTo(mx + 28*scaleX, my + 15*scaleY);
        ctx.moveTo(mx - 24*scaleX, my - 10*scaleY); ctx.lineTo(mx - 28*scaleX, my + 15*scaleY);
        ctx.stroke();

        ctx.fillStyle = '#06b6d4';
        const joints = [[mx, my-20*scaleY], [mx-24*scaleX, my-10*scaleY], [mx+24*scaleX, my-10*scaleY], [mx, my+15*scaleY]];
        joints.forEach(j => {
          ctx.beginPath();
          ctx.arc(j[0], j[1], 3, 0, Math.PI * 2);
          ctx.fill();
        });
      }
    } else if (state.activeMediaSource === 'video') {
      // Generate two simulated moving boxes traversing the screen
      const time = Date.now() / 3000;
      
      // Target 1
      const x1 = (300 + Math.sin(time) * 180) * scaleX;
      const y1 = (180 + Math.cos(time * 0.5) * 40) * scaleY;
      const boxW1 = 70 * scaleX;
      const boxH1 = 140 * scaleY;
      
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 2;
      ctx.strokeRect(x1 - boxW1/2, y1 - boxH1/2, boxW1, boxH1);
      ctx.fillStyle = '#10b981';
      ctx.fillRect(x1 - boxW1/2, y1 - boxH1/2 - 16*scaleY, boxW1, 16*scaleY);
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold ${Math.round(8*scaleX)}px var(--font-mono)`;
      ctx.fillText(`WORKER Compliant`, x1 - boxW1/2 + 4, y1 - boxH1/2 - 5*scaleY);

      // Target 2 (Mock violation)
      const x2 = (300 + Math.sin(time + Math.PI) * 160) * scaleX;
      const y2 = (190 + Math.sin(time * 0.7) * 30) * scaleY;
      const boxW2 = 70 * scaleX;
      const boxH2 = 140 * scaleY;
      
      const hasAlert = chkHelmet.checked;
      const boxColor = hasAlert ? '#ef4444' : '#10b981';
      
      ctx.strokeStyle = boxColor;
      ctx.lineWidth = 2;
      ctx.strokeRect(x2 - boxW2/2, y2 - boxH2/2, boxW2, boxH2);
      ctx.fillStyle = boxColor;
      ctx.fillRect(x2 - boxW2/2, y2 - boxH2/2 - 16*scaleY, boxW2, 16*scaleY);
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold ${Math.round(8*scaleX)}px var(--font-mono)`;
      
      const text = hasAlert ? 'WARNING: HELMET' : 'WORKER OK';
      ctx.fillText(`${text}`, x2 - boxW2/2 + 4, y2 - boxH2/2 - 5*scaleY);

      if (hasAlert) {
        triggerViolationEvent('dock', 'helmet', 'Missing PPE: Safety Helmet Violation', 'warning');
      }
    } else if (state.activeMediaSource === 'image') {
      // 2 Static diagnostic bounding boxes
      // Box 1
      const bx1 = 180 * scaleX;
      const by1 = 120 * scaleY;
      const bw1 = 90 * scaleX;
      const bh1 = 180 * scaleY;
      
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 2;
      ctx.strokeRect(bx1, by1, bw1, bh1);
      ctx.fillStyle = '#10b981';
      ctx.fillRect(bx1, by1 - 16*scaleY, bw1, 16*scaleY);
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold ${Math.round(8*scaleX)}px var(--font-mono)`;
      ctx.fillText('SUBJECT 01 COMPLIANT', bx1 + 4, by1 - 5*scaleY);

      // Box 2 (helmet missing)
      const bx2 = 360 * scaleX;
      const by2 = 100 * scaleY;
      const bw2 = 90 * scaleX;
      const bh2 = 190 * scaleY;
      
      const missingHelmet = chkHelmet.checked;
      const col = missingHelmet ? '#ef4444' : '#10b981';
      
      ctx.strokeStyle = col;
      ctx.lineWidth = 2;
      ctx.strokeRect(bx2, by2, bw2, bh2);
      ctx.fillStyle = col;
      ctx.fillRect(bx2, by2 - 16*scaleY, bw2, 16*scaleY);
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold ${Math.round(8*scaleX)}px var(--font-mono)`;
      ctx.fillText(missingHelmet ? 'BREACH: NO HELMET' : 'SUBJECT 02 SECURE', bx2 + 4, by2 - 5*scaleY);

      if (missingHelmet) {
        triggerViolationEvent('dock', 'helmet', 'Missing PPE: Safety Helmet Violation', 'warning');
      }
    }
  }

  // Ray casting algorithm for polygon bounds intersection
  function isPointInPolygon(point, polygon) {
    const x = point[0], y = point[1];
    let inside = false;
    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
      const xi = polygon[i][0], yi = polygon[i][1];
      const xj = polygon[j][0], yj = polygon[j][1];
      const intersect = ((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
      if (intersect) inside = !inside;
    }
    return inside;
  }

  // Live stream loop execution
  function loop() {
    if (state.currentView === 'dashboard') {
      const width = feedCanvas.width;
      const height = feedCanvas.height;

      if (state.backendConnected && state.backendImage) {
        try {
          feedCtx.drawImage(state.backendImage, 0, 0, width, height);
        } catch (err) {
          feedCtx.fillStyle = '#0a0d17';
          feedCtx.fillRect(0, 0, width, height);
          feedCtx.fillStyle = '#fff';
          feedCtx.font = '14px sans-serif';
          feedCtx.fillText("Connecting to Python Edge Stream...", width/2 - 120, height/2);
        }
      } else if (state.activeMediaSource === 'sim' || state.activeMediaSource === 'industrial') {
        drawStreamSimulation(feedCtx, feedCanvas, state.activeFeed);
      } else if (state.activeMediaSource === 'webcam' || state.activeMediaSource === 'video') {
        // Render current video frame to canvas
        try {
          feedCtx.drawImage(hiddenVideo, 0, 0, width, height);
          drawMediaDetectorOverlay(feedCtx, width, height);
        } catch (err) {
          // Video frame not ready, draw loading indicator
          feedCtx.fillStyle = '#000';
          feedCtx.fillRect(0, 0, width, height);
          feedCtx.fillStyle = '#fff';
          feedCtx.font = '14px sans-serif';
          feedCtx.fillText("Waiting for Video Stream...", width/2 - 80, height/2);
        }
      } else if (state.activeMediaSource === 'image' && state.uploadedImage) {
        // Draw static image and overlay static boxes
        feedCtx.drawImage(state.uploadedImage, 0, 0, width, height);
        drawMediaDetectorOverlay(feedCtx, width, height);
      }
    } else if (state.currentView === 'streams') {
      for (const key in streamCanvases) {
        const c = streamCanvases[key];
        if (state.backendConnected && key === state.activeFeed && state.backendImage) {
          try {
            c.ctx.drawImage(state.backendImage, 0, 0, c.el.width, c.el.height);
          } catch (e) {
            drawStreamSimulation(c.ctx, c.el, key);
          }
        } else {
          drawStreamSimulation(c.ctx, c.el, key);
        }
      }
    }
    
    // Schedule next frame based on FPS slider setting
    setTimeout(() => {
      requestAnimationFrame(loop);
    }, 1000 / state.fps);
  }

  // ==========================================
  // 12. INITIALIZATION
  // ==========================================
  // ==========================================
  // 13. PYTHON BACKEND INTEGRATION
  // ==========================================
  state.backendConnected = false;
  state.backendImage = null;

  async function initBackend() {
    // DOM Elements for backend settings
    const btnSaveCamSource = document.getElementById('btn-save-cam-source');
    const settingCamSource = document.getElementById('setting-cam-source');
    const btnSaveModelPath = document.getElementById('btn-save-model-path');
    const settingModelPath = document.getElementById('setting-model-path');
    const modelStatusBadge = document.getElementById('model-status-badge');
    const systemStatusText = document.getElementById('system-status-text');
    const modelVersionText = document.getElementById('model-version-text');

    // Bind settings buttons
    if (btnSaveCamSource) {
      btnSaveCamSource.addEventListener('click', async () => {
        const source = settingCamSource.value.trim();
        if (!source) return;
        showToast('Config Dispatch', `Applying camera source: ${source}`, 'warning');
        await sendBackendConfig({ cameraSource: source });
      });
    }

    if (btnSaveModelPath) {
      btnSaveModelPath.addEventListener('click', async () => {
        const path = settingModelPath.value.trim();
        if (!path) return;
        showToast('Model Loader', `Dispatching custom model path: ${path}`, 'warning');
        if (modelStatusBadge) {
          modelStatusBadge.textContent = 'LOADING...';
          modelStatusBadge.style.color = 'var(--color-warning)';
        }
        const resp = await sendBackendConfig({ modelPath: path });
        if (resp && resp.status === 'success') {
          if (modelStatusBadge) {
            modelStatusBadge.textContent = 'LOADED';
            modelStatusBadge.style.color = 'var(--color-success)';
          }
          if (modelVersionText && resp.model_path) {
            const baseName = resp.model_path.split(/[\\/]/).pop();
            modelVersionText.textContent = baseName;
          }
          showToast('Model Success', `Custom YOLO model successfully loaded.`, 'warning');
        } else {
          if (modelStatusBadge) {
            modelStatusBadge.textContent = 'ERROR';
            modelStatusBadge.style.color = 'var(--color-danger)';
          }
          showToast('Model Error', `Failed to load model file. Backend using fallback.`, 'danger');
        }
      });
    }

    const settingAiMode = document.getElementById('setting-ai-mode');
    if (settingAiMode) {
      settingAiMode.addEventListener('change', async (e) => {
        const mode = e.target.value;
        showToast('AI Mode Switch', `Switching to AI inference model: ${mode}`, 'warning');
        
        let path = '';
        if (mode === 'best.pt') {
          path = 'best.pt';
        } else if (mode === 'yolov8n.pt') {
          path = 'yolov8n.pt';
        } else {
          path = 'fallback';
        }
        
        if (modelStatusBadge) {
          modelStatusBadge.textContent = 'LOADING...';
          modelStatusBadge.style.color = 'var(--color-warning)';
        }
        
        const resp = await sendBackendConfig({ modelPath: path });
        if (resp && resp.status === 'success') {
          if (modelStatusBadge) {
            const isLoaded = (path !== 'fallback');
            modelStatusBadge.textContent = isLoaded ? 'LOADED' : 'OFFLINE (FALLBACK)';
            modelStatusBadge.style.color = isLoaded ? 'var(--color-success)' : 'var(--color-warning)';
          }
          if (modelVersionText && resp.model_path) {
            const baseName = resp.model_path.split(/[\\/]/).pop();
            modelVersionText.textContent = baseName;
          }
          showToast('AI Switch Success', `Inference engine loaded successfully.`, 'warning');
        } else {
          if (modelStatusBadge) {
            modelStatusBadge.textContent = 'ERROR';
            modelStatusBadge.style.color = 'var(--color-danger)';
          }
          showToast('AI Switch Error', `Failed to load selected model weights.`, 'danger');
        }
      });
    }

    // Connect existing settings changes to backend
    sliderConf.addEventListener('change', () => {
      sendBackendConfig({ confidenceThreshold: state.confidenceThreshold });
    });

    const triggerBackendConfig = () => {
      sendBackendConfig({
        activeDetectors: {
          helmet: chkHelmet.checked,
          vest: chkVest.checked,
          goggles: chkGoggles.checked,
          zones: chkZones.checked
        },
        visualization: {
          showBoxes: diagShowBoxes.checked,
          showSkeleton: diagShowSkeleton.checked,
          showHeatmap: diagShowHeatmap.checked
        },
        activeFeed: state.activeFeed
      });
    };

    [chkHelmet, chkVest, chkGoggles, chkZones, diagShowBoxes, diagShowSkeleton, diagShowHeatmap].forEach(el => {
      if (el) el.addEventListener('change', triggerBackendConfig);
    });

    mainFeedSelect.addEventListener('change', triggerBackendConfig);

    // Initial check
    try {
      const response = await fetch('/api/status');
      if (response.ok) {
        const data = await response.json();
        state.backendConnected = true;
        state.backendImage = new Image();
        state.backendImage.src = `/video_feed?t=${Date.now()}`;
        
        if (systemStatusText) {
          systemStatusText.textContent = 'HYBRID EDGE BACKEND';
          systemStatusText.style.color = 'var(--color-primary)';
        }
        
        if (modelVersionText && data.model_path) {
          const baseName = data.model_path.split(/[\\/]/).pop();
          modelVersionText.textContent = baseName;
        }

        if (modelStatusBadge && data.model_loaded) {
          modelStatusBadge.textContent = 'LOADED';
          modelStatusBadge.style.color = 'var(--color-success)';
        }
        
        if (settingCamSource) settingCamSource.value = data.source || '0';
        if (settingModelPath && data.model_path && data.model_path !== 'Default (OpenCV Fallback)' && data.model_path !== 'best.pt' && data.model_path !== 'yolov8n.pt' && data.model_path !== 'fallback') {
          settingModelPath.value = data.model_path;
        }
        if (settingAiMode) {
          if (data.model_path === 'fallback' || data.model_path.includes('Fallback')) {
            settingAiMode.value = 'fallback';
          } else if (data.model_path.endsWith('yolov8n.pt')) {
            settingAiMode.value = 'yolov8n.pt';
          } else {
            settingAiMode.value = 'best.pt';
          }
        }

        showToast('Backend Connected', 'IndustrialVision Python CV backend server online.', 'warning');
        
        // Start polling telemetry and active alerts
        setInterval(pollBackendTelemetry, 1000);
      }
    } catch (e) {
      console.log("[initBackend] Backend offline. Running in client-side simulation mode.");
    }
  }

  async function sendBackendConfig(config) {
    if (!state.backendConnected) return null;
    try {
      const response = await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
      });
      return await response.json();
    } catch (err) {
      console.error("[sendBackendConfig] Error:", err);
      return null;
    }
  }

  async function pollBackendTelemetry() {
    if (!state.backendConnected) return;
    try {
      const response = await fetch('/api/telemetry');
      if (response.ok) {
        const data = await response.json();
        
        // 1. Sync telemetry dashboard elements
        if (data.telemetry) {
          state.telemetry = data.telemetry;
          telTemp.textContent = `${state.telemetry.temp} °C`;
          telGas.textContent = `${state.telemetry.gas} ppm`;
          telHumidity.textContent = `${state.telemetry.humidity}%`;
          telNoise.textContent = `${state.telemetry.noise} dBA`;
          
          if (state.telemetry.noise > 82) {
            telNoiseGlow.className = 'telemetry-circle warning-glow';
          } else {
            telNoiseGlow.className = 'telemetry-circle cyan-glow';
          }
        }
        
        // 2. Sync active violations / alerts
        if (data.active_alerts) {
          // Identify which types of violations were active
          const activeTypes = new Set(data.active_alerts.map(a => a.type));
          
          // Trigger events for active violations
          data.active_alerts.forEach(alert => {
            const detailMsg = alert.details || `Safety Breach: ${alert.type} Violation`;
            triggerViolationEvent(state.activeFeed, alert.type, detailMsg, alert.severity || 'danger');
          });

          // Automatically resolve violations that are no longer reported by the backend
          const categories = ['helmet', 'vest', 'goggles', 'intrusion'];
          categories.forEach(cat => {
            if (!activeTypes.has(cat)) {
              const unresolved = state.violations.find(v => v.zone === state.activeFeed && v.classType === cat && v.status === 'unresolved');
              if (unresolved) {
                resolveViolation(unresolved.id);
              }
            }
          });
        }
      }
    } catch (err) {
      console.error("[pollBackendTelemetry] Error:", err);
    }
  }

  // ==========================================
  // 14. AUTHENTICATION & GLOBAL SEARCH (Python APIs)
  // ==========================================
  
  function checkAuthentication() {
    const isAuth = sessionStorage.getItem('authenticated');
    const loginContainer = document.getElementById('login-container');
    const appContainer = document.getElementById('app-container');
    
    if (isAuth === 'true') {
      if (loginContainer) loginContainer.style.display = 'none';
      if (appContainer) appContainer.style.display = 'flex';
      return true;
    } else {
      if (loginContainer) loginContainer.style.display = 'flex';
      if (appContainer) appContainer.style.display = 'none';
      return false;
    }
  }

  // Bind Login form submit
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const usernameInput = document.getElementById('username').value.trim();
      const passwordInput = document.getElementById('password').value.trim();
      const errorMsg = document.getElementById('login-error-msg');
      
      // If backend is connected, use Python API validation
      if (state.backendConnected) {
        try {
          const response = await fetch('/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: usernameInput, password: passwordInput })
          });
          
          if (response.ok) {
            sessionStorage.setItem('authenticated', 'true');
            checkAuthentication();
            showToast('Secure Entrance', 'Operator authenticated by Python Edge Backend.', 'warning');
          } else {
            const data = await response.json();
            if (errorMsg) {
              errorMsg.style.display = 'flex';
              errorMsg.querySelector('span').textContent = data.message || 'Invalid credentials.';
            }
          }
        } catch (err) {
          console.error("Backend login error:", err);
          localLoginValidate(usernameInput, passwordInput, errorMsg);
        }
      } else {
        localLoginValidate(usernameInput, passwordInput, errorMsg);
      }
    });
  }

  function localLoginValidate(username, password, errorMsgEl) {
    if (username === 'admin' && password === 'admin123') {
      sessionStorage.setItem('authenticated', 'true');
      checkAuthentication();
      showToast('Offline System Unlock', 'Local dashboard simulation unlocked.', 'warning');
    } else {
      if (errorMsgEl) {
        errorMsgEl.style.display = 'flex';
        errorMsgEl.querySelector('span').textContent = 'Invalid username or password.';
      }
    }
  }

  // Bind Sign Out button
  const btnSignOut = document.getElementById('btn-sign-out');
  if (btnSignOut) {
    btnSignOut.addEventListener('click', (e) => {
      e.preventDefault();
      sessionStorage.removeItem('authenticated');
      window.location.reload();
    });
  }

  // Global Search Box Controller
  const globalSearch = document.getElementById('global-search');
  const globalSearchResults = document.getElementById('global-search-results');
  
  if (globalSearch && globalSearchResults) {
    globalSearch.addEventListener('input', async (e) => {
      const val = e.target.value.trim();
      if (!val) {
        globalSearchResults.style.display = 'none';
        globalSearchResults.innerHTML = '';
        return;
      }
      
      // Query Python Search API if backend is connected
      if (state.backendConnected) {
        try {
          const response = await fetch(`/api/search?q=${encodeURIComponent(val)}`);
          if (response.ok) {
            const data = await response.json();
            renderSearchResults(data);
          }
        } catch (err) {
          console.error("Python search query failed, using local search fallback:", err);
          renderLocalSearchResults(val);
        }
      } else {
        renderLocalSearchResults(val);
      }
    });
    
    // Close search popup if clicking outside
    document.addEventListener('click', (e) => {
      if (!globalSearch.contains(e.target) && !globalSearchResults.contains(e.target)) {
        globalSearchResults.style.display = 'none';
      }
    });
  }

  function renderSearchResults(data) {
    globalSearchResults.innerHTML = '';
    
    if (data.length === 0) {
      const item = document.createElement('div');
      item.className = 'global-search-item';
      item.style.cursor = 'default';
      item.innerHTML = `<span style="color: var(--text-muted); font-size:12px;">No matching results found.</span>`;
      globalSearchResults.appendChild(item);
      globalSearchResults.style.display = 'block';
      return;
    }
    
    data.forEach(res => {
      const item = document.createElement('div');
      item.className = 'global-search-item';
      
      let badgeColor = 'var(--color-primary)';
      if (res.type === 'alert') badgeColor = 'var(--color-danger)';
      if (res.type === 'zone') badgeColor = 'var(--color-secondary)';
      
      item.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <span class="search-title">${res.name}</span>
          <span style="font-size:9px; background:${badgeColor}; color:#000; padding:1px 5px; border-radius:4px; font-weight:700; font-family:var(--font-mono); text-transform:uppercase;">${res.type}</span>
        </div>
        <div class="search-meta">
          <span>Location: ${res.location}</span>
          <span style="color: ${res.status.includes('Compliant') || res.status.includes('Secure') || res.status.includes('MONITORING') ? 'var(--color-success)' : 'var(--color-danger)'}">${res.status}</span>
        </div>
      `;
      
      item.addEventListener('click', () => {
        if (res.zone_key) {
          state.activeFeed = res.zone_key;
          mainFeedSelect.value = res.zone_key;
          
          const dashboardNav = document.querySelector('[data-view="dashboard"]');
          if (dashboardNav) dashboardNav.click();
          
          showToast('Search Navigation', `Swapped camera feed to: ${res.location}`, 'warning');
        }
        
        globalSearchResults.style.display = 'none';
        globalSearch.value = '';
      });
      
      globalSearchResults.appendChild(item);
    });
    
    globalSearchResults.style.display = 'block';
  }

  function renderLocalSearchResults(query) {
    const q = query.toLowerCase();
    const mockResults = [];
    
    for (const key in state.zones) {
      const zone = state.zones[key];
      zone.workers.forEach(w => {
        if (w.name.toLowerCase().includes(q) || w.id.toString().includes(q)) {
          const compliance = w.status === 'VIOLATION' ? 'Non-Compliant' : 'Compliant';
          mockResults.push({
            type: 'worker',
            name: `${w.id} | ${w.name}`,
            location: zone.name,
            status: `${w.status} (${compliance})`,
            zone_key: key
          });
        }
      });
    }
    
    renderSearchResults(mockResults.slice(0, 6));
  }

  function init() {
    // Check secure portal sign-in state
    checkAuthentication();

    initCharts();
    
    // Resize canvasses to match layouts
    resizeCanvases();
    setupStreamGridSizing();
    
    // Pre-populate some historical violations so logs don't look completely empty on launch
    const baselineDate = new Date();
    state.violations = [
      {
        id: 'hist1',
        timestamp: new Date(baselineDate - 500000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        rawTimestamp: new Date(baselineDate - 500000),
        zone: 'dock',
        zoneName: state.zones.dock.name,
        classType: 'vest',
        message: 'Missing PPE: Safety Vest Violation',
        severity: 'warning',
        status: 'resolved'
      },
      {
        id: 'hist2',
        timestamp: new Date(baselineDate - 900000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        rawTimestamp: new Date(baselineDate - 900000),
        zone: 'chemical',
        zoneName: state.zones.chemical.name,
        classType: 'gas',
        message: 'Hazardous H2S Gas Leak Detected',
        severity: 'danger',
        status: 'resolved'
      },
      {
        id: 'hist3',
        timestamp: new Date(baselineDate - 1800000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        rawTimestamp: new Date(baselineDate - 1800000),
        zone: 'assembly',
        zoneName: state.zones.assembly.name,
        classType: 'helmet',
        message: 'Missing PPE: Safety Helmet Violation',
        severity: 'warning',
        status: 'resolved'
      }
    ];

    renderViolationsList();
    renderIncidentTable();
    updateGeneralStats();

    // Trigger icon replacements
    lucide.createIcons();
    
    // Initialize backend connection
    initBackend();

    // Start simulations loop
    requestAnimationFrame(loop);
  }

  init();
});
