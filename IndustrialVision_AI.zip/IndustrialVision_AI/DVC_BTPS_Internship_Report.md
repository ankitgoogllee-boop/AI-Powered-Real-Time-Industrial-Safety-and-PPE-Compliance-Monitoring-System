# INTERNSHIP PROJECT REPORT

**PROJECT TITLE:**  
### **AI-Powered Real-Time Industrial Safety & PPE Compliance Monitoring System**

**HOST ORGANIZATION:**  
**Damodar Valley Corporation (DVC)**  
**Bokaro Thermal Power Station (BTPS), Bokaro, Jharkhand, India**

**SUBMITTED BY:**  
*Ankit (Intern, Computer Science & Engineering / Information Technology)*  

---

## 1. ABSTRACT
In heavy industrial sites like the Bokaro Thermal Power Station (BTPS), Damodar Valley Corporation (DVC), safety compliance is a critical priority. Manual supervision of safety gears (such as hard hats, high-vis vests, and safety goggles) is highly challenging in extensive, high-risk zones (such as Coal Handling Plants, Turbine Halls, Boiler Houses, and Chemical treatment facilities). This project details the design, implementation, and deployment of **IndustrialVision AI**—an Edge-AI Computer Vision dashboard. 

Using **YOLOv8 deep learning** model architectures, **human pose estimation**, and **color segmentation fallbacks**, the system automates real-time verification of Personal Protective Equipment (PPE). Additionally, the system provides proactive posture-based **Fall Detection**, **Vehicle-Pedestrian Collision Avoidance**, and **Restricted Boundary Intrusion alerts**. Running on a local Flask server connected to edge CCTV feeds, the system processes video streams via background-threaded camera controllers, maintaining robust operations even during camera feed drops.

---

## 2. INTRODUCTION
### 2.1 About Damodar Valley Corporation (DVC) & BTPS
Damodar Valley Corporation (DVC) is a premier power utility in India, operating multiple thermal and hydel power stations. The Bokaro Thermal Power Station (BTPS) is one of DVC's key coal-fired units. Industrial operations at BTPS involve heavy machinery, high-temperature boiler units, chemical storehouses, and high-voltage transmission lines. 

### 2.2 Problem Statement
Despite strict safety guidelines, workers at coal handling plants or maintenance corridors occasionally bypass safety protocols (e.g., removing hard hats or high-vis clothing). Current safety audits rely on:
- Manual supervisions (subject to human fatigue and blind spots).
- CCTV recording checks (reactive, analyzing incidents *after* they occur rather than preventing them).

### 2.3 Project Objective
To design and deploy a local edge-computational vision pipeline that:
- Inspects real-time video streams for PPE compliance.
- Alerts supervisors visually and audibly on safety breaches.
- Monitors restricted perimeter boundaries.
- Prevents collisions between moving machinery (such as forklifts/conveyors) and pedestrian workers.

---

## 3. SYSTEM ARCHITECTURE

The system is designed as a hybrid edge visual processor:
1. **Edge Processor (Python Engine)**: Receives video feeds, decodes frames, performs YOLO inference, runs pose skeleton checks, and calculates proximity vectors.
2. **Local API Server (Flask)**: Hosts REST endpoints for system state (`/api/status`), real-time search queries (`/api/search`), and streams JPEG-encoded MJPEG video feeds (`/video_feed`).
3. **Command Dashboard (HTML5/CSS3/JS)**: A dark-themed safety dashboard displaying real-time metrics, incident notifications, and configuration panels.

```
+-----------------------------------------------------------------+
|                        CCTV/Webcam Feed                         |
+-----------------------------------------------------------------+
                                |
                                v
+-----------------------------------------------------------------+
|            Python Edge Visual Engine (vision.py)                |
|  - Background Frame Acquisition Thread                          |
|  - YOLOv8 Custom Weights (best.pt) or CV Fallback               |
|  - Pose Estimation & Distance Vectors                           |
+-----------------------------------------------------------------+
                                |
                                v
+-----------------------------------------------------------------+
|             Flask Local Web Server (app.py)                     |
|  - /video_feed (MJPEG Stream)     - /api/login (Auth Gateway)   |
|  - /api/telemetry (Sensor Data)  - /api/search (Search Engine) |
+-----------------------------------------------------------------+
                                |
                                v
+-----------------------------------------------------------------+
|             Web Browser Command Center (index.html)             |
|  - Secure Authentication Portal  - Real-Time Global Search      |
|  - Live Feed Camera Monitor      - Configuration Settings Tab   |
+-----------------------------------------------------------------+
```

---

## 4. DESIGN METHODOLOGY & MATHEMATICAL MODELS

### 4.1 PPE Accessory Mapping (Intersection over Area - IoA)
To verify if a worker is wearing safety gear, the system first detects the bounding box of the worker ($Box_{Person}$) and the bounding boxes of safety accessories ($Box_{Accessory}$) like helmets or vests. Rather than simple center-point checks, the system computes the **Intersection over Area (IoA)** to confirm overlap:

\[
IoA = \frac{\text{Area}(Box_{Accessory} \cap Box_{Person})}{\text{Area}(Box_{Accessory})}
\]

If $IoA > 0.4$, the accessory is classified as worn by that specific worker. If no matching accessory intersects with the worker, the system raises a "Missing PPE" alert for that class.

### 4.2 Proximity-Based Collision Avoidance
To prevent accidents near high-traffic areas (like coal bunkers or turbine docks), the system tracks machinery (such as forklifts) and pedestrian workers. The system calculates the Euclidean distance $D$ between the machinery center $(X_M, Y_M)$ and the worker's feet coordinate $(X_W, Y_W)$:

\[
D = \sqrt{(X_M - X_W)^2 + (Y_M - Y_W)^2}
\]

If $D < \theta$ (where $\theta$ is a threshold equivalent to 15 meters on site), a flashing collision vector line is drawn between the targets, and a high-priority proximity alert is sent.

### 4.3 Pose-Based Fall Detection
Slipping and falling inside turbine boiler galleries is a serious hazard. The system monitors the aspect ratio of the worker's bounding box:

\[
AR = \frac{\text{Width of } Box_{Person}}{\text{Height of } Box_{Person}}
\]

Under normal conditions, a standing worker maintains $AR < 1.0$. If $AR > 1.3$ (the box is wide rather than tall) and the height of the head joint drops rapidly relative to feet history, the system classifies this state as a **Critical Fall / Worker Down**.

---

## 5. TECHNICAL STACK & SOFTWARE IMPLEMENTATION

### 5.1 Technology Stack
- **Programming Language:** Python 3.14 (Backend Engine)
- **Computer Vision Libraries:** OpenCV 4.10, Numpy
- **Deep Learning Framework:** PyTorch, Ultralytics YOLOv8
- **Web App Hosting:** Flask (Python Micro-framework)
- **User Interface:** HTML5, Vanilla CSS3 (Custom design system), Vanilla JS (ES6+)

### 5.2 Project Directory Structure
```
D:\IndustrialVision_AI\
│
├── app.py                      # Flask Server (Routes, APIs, OpenBLAS Thread Controller)
├── vision.py                   # Edge AI Processor (YOLO, Pose, Proximity, fall checking)
├── main.py                     # Standalone Desktop OpenCV Visualizer Script
├── best.pt                     # Custom YOLOv8 model weights
├── index.html                  # Dashboard HTML GUI (Login & Search screens included)
├── style.css                   # Core Dashboard Dark/Neon CSS Theme
├── app.js                      # UI Events Handler, telemetries, charts, and API hooks
└── DVC_BTPS_Internship_Report.md # This Internship Report Document
```

### 5.3 Technical Challenges & Solutions
1. **Windows Paging File Limits (`WinError 1455`)**:
   - *Challenge:* PyTorch's massive CUDA DLLs failed to allocate virtual memory on host startup, crashing the server.
   - *Solution:* Implemented **dynamic lazy loading** of YOLO classes. PyTorch is only loaded when the user switches to AI mode, and failures are caught gracefully to fallback to OpenCV.
2. **OpenBLAS Thread Allocation Crash**:
   - *Challenge:* OpenBLAS tried to pre-allocate memory pools for all CPU cores, causing startup crashes.
   - *Solution:* Restricted environment threads to `1` thread on boot using `os.environ["OPENBLAS_NUM_THREADS"] = "1"`.
3. **Webcam Locking Thread Freeze**:
   - *Challenge:* If the selected webcam was busy, standard `cv2.VideoCapture` blocked Flask, preventing the dashboard webpage from loading.
   - *Solution:* Implemented **background multi-threaded frame acquisition** with self-healing capture releases.

---

## 6. FEATURES IMPLEMENTED

### 6.1 Secure Operator Authentication Portal
Access to the BTPS command center is restricted. On load, the system displays a secure Sign-In portal. Authentication is processed by the Python Flask backend at `POST /api/login`.
- **Default Login:** Username: `admin` | Password: `admin123`

### 6.2 Real-Time Global Search
A search field inside the header connects to `GET /api/search` in Python. Operators can type in a worker's ID (e.g., `W-102`), a zone name (e.g., `Boiler House`), or an active violation class. Selecting a search result automatically redirects the active video stream monitor to that zone.

### 6.3 Dynamic AI Mode Selection
Under Settings, safety supervisors can dynamically switch the active model:
- `best.pt` (Custom trained YOLO safety model).
- `yolov8n.pt` (Standard COCO detector).
- OpenCV Fallback (For CPU-bound local edge testing).

---

## 7. FUTURE RECOMMENDATIONS FOR DVC BTPS
- **Thermal Camera Integration**: To monitor boiler outer skin temperature and detect overheating.
- **PLC Relay Trigger Integration**: In case of restricted zone intrusion, the system can send signals directly to PLCs to automatically halt nearby hazard conveyors.
- **Drone Vision Integration**: Running the same Python vision scripts on drone feeds to inspect tall chimneys and coal stockpile yards automatically.

---

## 8. ACKNOWLEDGEMENT & CONCLUSION
I express my gratitude to the management of **Damodar Valley Corporation (DVC)** at **Bokaro Thermal Power Station (BTPS)** for providing the resources, guidance, and opportunity to develop this safety monitoring system. 

The developed **IndustrialVision AI** edge processor demonstrates that real-time safety automation using Deep Learning is feasible, highly responsive, and capable of functioning under system constraints. This edge vision platform successfully minimizes human errors, moving BTPS closer to a fully zero-accident smart factory floor.
