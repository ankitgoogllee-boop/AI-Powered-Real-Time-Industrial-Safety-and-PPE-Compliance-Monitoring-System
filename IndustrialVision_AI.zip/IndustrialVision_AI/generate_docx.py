import os
import sys

def create_report():
    # Try importing docx
    try:
        from docx import Document
        from docx.shared import Pt, Inches, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH
    except ImportError:
        print("python-docx not installed. Please run: pip install python-docx")
        return

    # Use the diagram image from the local project folder
    local_img_path = "ai_safety_system_diagram.jpg"
    if not os.path.exists(local_img_path):
        local_img_path = None

    # Set document save path on Desktop
    desktop = os.path.join(os.path.expanduser("~"), "Desktop")
    if not os.path.exists(desktop):
        desktop = os.path.join(os.path.expanduser("~"), "OneDrive", "Desktop")
        if not os.path.exists(desktop):
            desktop = "."
            
    doc_path = os.path.join(desktop, "DVC_BTPS_Internship_Report.docx")
    print(f"Generating Word Document at: {doc_path}")
    
    doc = Document()
    
    # 1. PAGE SETUP (Margins)
    for section in doc.sections:
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)
        
    # Set default style font
    style = doc.styles['Normal']
    font = style.font
    font.name = 'Segoe UI'
    font.size = Pt(11)
    
    # 2. TITLE PAGE (Cover Page)
    # Organization Header
    p_org = doc.add_paragraph()
    p_org.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run_org = p_org.add_run("DAMODAR VALLEY CORPORATION\n")
    run_org.bold = True
    run_org.font.size = Pt(16)
    run_org.font.color.rgb = RGBColor(12, 35, 64)
    
    # Add spacing
    for _ in range(5):
        doc.add_paragraph()
        
    # Title
    p_title = doc.add_paragraph()
    p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run_title = p_title.add_run("INTERNSHIP PROJECT REPORT\n\n")
    run_title.bold = True
    run_title.font.size = Pt(20)
    
    run_subtitle = p_title.add_run("AI-Powered Real-Time Safety & PPE Compliance Monitoring System\n")
    run_subtitle.bold = True
    run_subtitle.font.size = Pt(16)
    run_subtitle.font.color.rgb = RGBColor(194, 64, 12) # Dark Orange
    
    # Add spacing
    for _ in range(5):
        doc.add_paragraph()
        
    # Host Location
    p_loc = doc.add_paragraph()
    p_loc.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run_loc = p_loc.add_run("Bokaro Thermal Power Station (BTPS)\nBokaro District, Jharkhand, India")
    run_loc.font.size = Pt(13)
    run_loc.font.color.rgb = RGBColor(85, 85, 85)
    
    # Add spacing
    for _ in range(5):
        doc.add_paragraph()
        
    # Metadata Columns
    p_meta = doc.add_paragraph()
    run_meta_title = p_meta.add_run("SUBMITTED BY:\t\t\t\tTRAINING DURATION:\n")
    run_meta_title.bold = True
    run_meta_title.font.size = Pt(10)
    
    run_meta_val = p_meta.add_run("Ankit\t\t\t\t\tJune - July 2026\nIntern (CSE / IT Branch)\t\t\tDVC BTPS Safety Division")
    run_meta_val.font.size = Pt(10)
    
    # Break to Page 2
    doc.add_page_break()
    
    # 3. CONTENT SECTIONS
    sections_content = [
        ("1. Abstract", [
            "In heavy industrial plants like the Bokaro Thermal Power Station (BTPS), operated by the Damodar Valley Corporation (DVC), safety compliance is paramount. Manual enforcement of safety equipment (hard hats, safety vests, and protective goggles) is a massive challenge in extensive, hazardous sectors like Coal Handling Plants (CHP), boiler zones, and high-voltage substation yards.",
            "This internship project details the development of IndustrialVision AI—an Edge-AI Computer Vision dashboard. By utilizing the YOLOv8 deep learning model, human pose estimation, and color-segmentation fallbacks, the system automates real-time PPE audits. It also features posture-based Fall Detection, Proactive Collision Warning vectors between machinery and workers, and Restricted Zone intrusion tracking.",
            "To ensure stable edge-device performance on Windows environments, the application implements background multi-threaded frame acquisition and a dynamic memory lazy loader. This loader catches PyTorch/OpenBLAS startup limits, allowing the server to operate continuously with zero-blocking safety fallbacks."
        ]),
        ("2. Introduction", [
            "2.1 DVC Bokaro Thermal Power Station (BTPS)",
            "Bokaro Thermal Power Station (BTPS) is one of the premier coal-fired power plants operated by DVC. The plant houses boiler galleries, steam turbine generator corridors, coal barrows, and chemical treatment reservoirs. Operating in this environment exposes personnel to hazards, making safety compliance critical.",
            "2.2 Problem Statement",
            "Standard safety management relies on manual inspection or passive CCTV recording checks, both of which are reactive and prone to human oversight. A proactive, automated system is required to inspect video streams, detect safety breaches instantly, and raise visual and acoustic alarms.",
            "2.3 Project Objectives",
            "- Develop a real-time computer vision pipeline for automated PPE compliance audits.\n"
            "- Implement posture-based fall detection to alert operators when a worker slips or collapses.\n"
            "- Design proximity calculations to prevent pedestrian-machinery collisions.\n"
            "- Deploy a secure, locally-hosted web command dashboard for site supervisors."
        ]),
        ("3. Design Methodology & Calculations", [
            "3.1 PPE Mapping (Intersection over Area - IoA)",
            "The system detects the bounding boxes of workers (Box_Person) and accessories (Box_Accessory). To map a helmet or vest to an individual worker, the system calculates the Intersection over Area (IoA) ratio:\n\n"
            "IoA = Area(Box_Accessory intersects Box_Person) / Area(Box_Accessory)\n\n"
            "If IoA > 0.40, the accessory is classified as successfully worn by the worker. If no matching helmet or vest overlaps a detected worker's bounding box, a safety breach alert is triggered.",
            "3.2 Proximity Collision Warning",
            "To prevent collisions, the system tracks moving vehicles (e.g. forklifts) and pedestrian workers. It computes the Euclidean distance d between the vehicle center (X_V, Y_V) and the worker's coordinate (X_W, Y_W):\n\n"
            "d = sqrt[ (X_V - X_W)^2 + (Y_V - Y_W)^2 ]\n\n"
            "If the distance falls below a safety threshold (equivalent to 15 meters), a red hazard line is drawn, and an alarm triggers.",
            "3.3 Pose Fall Detection",
            "Slipping and falling is a critical safety issue. The system monitors the aspect ratio (AR) of the worker's bounding box:\n\n"
            "AR = Width_Box / Height_Box\n\n"
            "If the aspect ratio exceeds 1.3 (horizontal box orientation) and the vertical head joint height drops rapidly, the system raises a Worker Down / Fall Alert."
        ]),
        ("4. System Architecture & Code", [
            "The system consists of three main components: a Python visual processor, a Flask server, and a web dashboard.",
            "Project Directory Structure:\n"
            "D:\\IndustrialVision_AI\\\n"
            "├── app.py                      # Flask Backend (APIs, OpenBLAS Thread Limits)\n"
            "├── vision.py                   # Edge AI Engine (YOLO, Pose, Proximity, Fall checks)\n"
            "├── main.py                     # Native Desktop OpenCV Visualizer App\n"
            "├── best.pt                     # Custom YOLOv8 model weights\n"
            "├── index.html                  # Dashboard HTML Web Panel (Login Page & Search)\n"
            "├── style.css                   # Core Neon Dark CSS Style\n"
            "└── app.js                      # UI Event Hooks, Charts, and telemetry updates",
            "4.1 OpenBLAS Memory Allocation Fix",
            "To prevent memory crashes in environment startups with low virtual memory, thread constraints were applied at the top of app.py and main.py:\n\n"
            "import os\n"
            "os.environ[\"OPENBLAS_NUM_THREADS\"] = \"1\"\n"
            "os.environ[\"OMP_NUM_THREADS\"] = \"1\"\n"
            "os.environ[\"MKL_NUM_THREADS\"] = \"1\""
        ]),
        ("5. Features & Results", [
            "5.1 Key Features Implemented",
            "- Secure Operator Authentication Portal: Restricts access via dynamic login checks. (Username: admin | Password: admin123).\n"
            "- Global Dashboard Search Bar: Real-time search suggestions allowing operators to filter by worker, camera, or alert type and switch feeds instantly.\n"
            "- Background Multithreading Grabber: Ensures camera streams do not block Flask server loading, falling back smoothly to mock visual simulations if the device is busy.",
            "5.2 Conclusion",
            "The IndustrialVision AI edge processor has been successfully configured and deployed. The system demonstrates that AI-based safety monitoring can be implemented locally on edge platforms, providing real-time alerts that enhance safety supervision at DVC BTPS."
        ])
    ]
    
    for heading, paras in sections_content:
        h = doc.add_heading(heading, level=1)
        h.runs[0].font.color.rgb = RGBColor(12, 35, 64)
        for p_text in paras:
            if p_text.startswith("2.1") or p_text.startswith("2.2") or p_text.startswith("2.3") or p_text.startswith("3.1") or p_text.startswith("3.2") or p_text.startswith("3.3") or p_text.startswith("4.1") or p_text.startswith("5.1") or p_text.startswith("5.2"):
                h_sub = doc.add_heading(p_text, level=2)
                h_sub.runs[0].font.color.rgb = RGBColor(85, 85, 85)
                h_sub.runs[0].font.size = Pt(13)
            elif "IoA =" in p_text or "d = " in p_text or "AR =" in p_text or "import os" in p_text or "├── app.py" in p_text:
                p_code = doc.add_paragraph()
                p_code.paragraph_format.left_indent = Inches(0.4)
                run_code = p_code.add_run(p_text)
                run_code.font.name = 'Consolas'
                run_code.font.size = Pt(9.5)
                run_code.font.color.rgb = RGBColor(40, 40, 40)
            else:
                doc.add_paragraph(p_text)
                
        # Embed system diagram image under the System Architecture section
        if heading.startswith("4. System Architecture") and local_img_path and os.path.exists(local_img_path):
            try:
                # Add picture
                p_img = doc.add_paragraph()
                p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
                run_img = p_img.add_run()
                run_img.add_picture(local_img_path, width=Inches(6.0))
                
                # Add caption
                p_caption = doc.add_paragraph()
                p_caption.alignment = WD_ALIGN_PARAGRAPH.CENTER
                run_caption = p_caption.add_run("Figure 1: AI Vision Prototyping Interface & HUD Analysis Dashboard")
                run_caption.italic = True
                run_caption.font.size = Pt(9.5)
                run_caption.font.color.rgb = RGBColor(100, 100, 100)
            except Exception as ex:
                print(f"[generate_docx] Error embedding picture: {ex}")
                
        doc.add_page_break()
        
    doc.save(doc_path)
    print("Report generated successfully.")

if __name__ == "__main__":
    create_report()
