import os
import cv2
import numpy as np
import time
import random
import traceback
import threading

# YOLO deep learning is lazy loaded to prevent OpenBLAS and PyTorch memory errors on server boot
YOLO_AVAILABLE = False
_YOLO_CLASS = None

def load_yolo_class():
    global YOLO_AVAILABLE, _YOLO_CLASS
    if _YOLO_CLASS is not None:
        return _YOLO_CLASS
    try:
        from ultralytics import YOLO
        _YOLO_CLASS = YOLO
        YOLO_AVAILABLE = True
        return _YOLO_CLASS
    except Exception as e:
        print(f"[VisionProcessor] YOLO/PyTorch lazy-load failed: {e}")
        YOLO_AVAILABLE = False
        return None

def is_yolo_supported():
    return load_yolo_class() is not None

def box_intersection_over_area(box_acc, box_person):
    """
    Calculates what percentage of the accessory box intersects with the person box.
    Used to map safety helmets, vests, and goggles to individual workers.
    """
    xA = max(box_acc[0], box_person[0])
    yA = max(box_acc[1], box_person[1])
    xB = min(box_acc[2], box_person[2])
    yB = min(box_acc[3], box_person[3])
    
    inter_area = max(0, xB - xA) * max(0, yB - yA)
    acc_area = (box_acc[2] - box_acc[0]) * (box_acc[3] - box_acc[1])
    
    if acc_area <= 0:
        return 0.0
    return float(inter_area / acc_area)

class VisionProcessor:
    def __init__(self, source="0", model_path=None):
        self.cap = None
        self.source = source
        self.model_path = model_path
        self.model = None
        self.is_fallback_sim = False
        
        # Threading-based frame grabber variables
        self.latest_frame = None
        self.read_thread = None
        self.running = False
        self.lock = threading.Lock()
        
        # Configuration parameters
        self.confidence_threshold = 0.85
        self.active_detectors = {
            "helmet": True,
            "vest": True,
            "goggles": True,
            "zones": True
        }
        
        # Visualization options
        self.show_boxes = True
        self.show_skeleton = True
        self.show_heatmap = True
        
        # Safety Zones
        self.restricted_zones = {
            "dock": np.array([[100, 150], [350, 150], [420, 280], [60, 280]], dtype=np.int32),
            "assembly": np.array([[80, 180], [480, 180], [480, 240], [80, 240]], dtype=np.int32),
            "chemical": np.array([[150, 100], [330, 100], [330, 220], [150, 220]], dtype=np.int32),
            "corridor": np.array([], dtype=np.int32)
        }
        self.active_zone_key = "dock"
        self.frame_count = 0
        self.last_alerts = []
        
        # ----------------------------------------------------
        # Simulated Factory Objects (For Offline/Camera-Offline AI Fallback)
        # ----------------------------------------------------
        self.sim_workers = [
            {
                "id": "W-101", "name": "John D.", "x": 120, "y": 100, "vx": 1.5, "vy": 0.8,
                "ppe": {"helmet": True, "vest": True, "goggles": True},
                "state": "walking", "breadcrumbs": [], "fall_timer": 150
            },
            {
                "id": "W-102", "name": "Bob K.", "x": 450, "y": 180, "vx": -1.2, "vy": 0.5,
                "ppe": {"helmet": True, "vest": True, "goggles": False},
                "state": "walking", "breadcrumbs": [], "fall_timer": 400
            },
            {
                "id": "W-103", "name": "Visitor M.", "x": 80, "y": 220, "vx": 0.8, "vy": -0.6,
                "ppe": {"helmet": False, "vest": True, "goggles": True},
                "state": "walking", "breadcrumbs": [], "fall_timer": 600
            }
        ]
        self.sim_forklift = {
            "x": 400, "y": 290, "vx": -2.0, "vy": -0.5, "width": 80, "height": 60
        }
        
        # Initialize camera source & YOLO model
        self.set_source(self.source)
        self.load_model(self.model_path)

    def set_source(self, source):
        """Dynamically switch video source (camera index, video file, or RTSP feed)"""
        # Stop previous background thread
        self.running = False
        if self.read_thread is not None:
            self.read_thread.join(timeout=1.0)
            self.read_thread = None
            
        if self.cap is not None:
            self.cap.release()
            self.cap = None
            
        self.source = source
        self.is_fallback_sim = False
        self.latest_frame = None
        
        # If camera is standard index
        if isinstance(source, str) and source.isdigit():
            actual_source = int(source)
        else:
            actual_source = source
            
        print(f"[VisionProcessor] Connecting to source: {actual_source}")
        self.cap = cv2.VideoCapture(actual_source)
        
        if isinstance(actual_source, int):
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
            
        # Start background reader thread if camera opens successfully
        if self.cap.isOpened():
            self.running = True
            self.read_thread = threading.Thread(target=self._bg_read_loop, daemon=True)
            self.read_thread.start()
            print("[VisionProcessor] Background camera reader thread started.")
        else:
            print("[VisionProcessor] Camera hardware failed to open. Automatically activating High-Fidelity AI Simulation Fallback.")
            self.is_fallback_sim = True

    def _bg_read_loop(self):
        """Daemon thread loop to capture frames from camera device without blocking main Flask threads"""
        consecutive_failures = 0
        while self.running:
            if self.cap is not None and self.cap.isOpened():
                try:
                    # Non-blocking read in background
                    ret, frame = self.cap.read()
                    if ret:
                        consecutive_failures = 0
                        with self.lock:
                            self.latest_frame = frame
                    else:
                        consecutive_failures += 1
                        time.sleep(0.1) # Sleep longer on failure
                except Exception as e:
                    print(f"[VisionProcessor bg_read] Error reading frame: {e}")
                    consecutive_failures += 1
                    time.sleep(0.2)
                
                # Self-healing: If camera is busy/blocked and fails to return frames 10 times in a row,
                # release the camera and close the thread to stop standard error warning spam.
                if consecutive_failures >= 10:
                    print("[VisionProcessor] Camera device failed to return frames 10 times. Switching to simulation.")
                    self.is_fallback_sim = True
                    self.running = False
                    if self.cap is not None:
                        self.cap.release()
                        self.cap = None
                    break
            else:
                break
            # Sleep to match standard webcam frame rates and prevent CPU overload (~30 FPS)
            time.sleep(0.03)

    def load_model(self, model_path):
        """Attempts to load a custom YOLO model path"""
        if model_path and not os.path.isabs(model_path):
            base_dir = os.path.dirname(os.path.abspath(__file__))
            model_path = os.path.join(base_dir, model_path)
            
        self.model_path = model_path
        
        YOLO = load_yolo_class()
        if YOLO is None:
            print("[VisionProcessor] Ultralytics YOLO library unavailable. Using OpenCV fallback pipeline.")
            self.model = None
            return False
            
        if not model_path:
            print("[VisionProcessor] Loading default yolov8n.pt...")
            try:
                self.model = YOLO("yolov8n.pt")
                return True
            except Exception as e:
                print(f"[VisionProcessor] Error loading default YOLO: {e}")
                self.model = None
                return False
                
        if not os.path.exists(model_path):
            print(f"[VisionProcessor] Custom model path not found: {model_path}")
            self.model = None
            return False
            
        try:
            print(f"[VisionProcessor] Loading custom YOLO model: {model_path}")
            self.model = YOLO(model_path)
            return True
        except Exception as e:
            print(f"[VisionProcessor] Failed to load custom weights: {e}")
            self.model = None
            return False

    def update_config(self, config):
        """Updates configurations from client settings"""
        if "confidenceThreshold" in config:
            self.confidence_threshold = float(config["confidenceThreshold"])
        if "activeDetectors" in config:
            self.active_detectors.update(config["activeDetectors"])
        if "visualization" in config:
            vis = config["visualization"]
            self.show_boxes = vis.get("showBoxes", self.show_boxes)
            self.show_skeleton = vis.get("showSkeleton", self.show_skeleton)
            self.show_heatmap = vis.get("showHeatmap", self.show_heatmap)
        if "activeFeed" in config:
            self.active_zone_key = config["activeFeed"]

    def _detect_ppe_opencv(self, frame, person_box):
        """HSV color-segmentation fallback checking for PPE compliance inside bounding box"""
        x1, y1, x2, y2 = person_box
        w, h = x2 - x1, y2 - y1
        
        detections = {
            "helmet": False,
            "vest": False,
            "goggles": True
        }
        
        if w <= 0 or h <= 0:
            return detections
            
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        
        # 1. Helmet Detection (Top 18% of box)
        head_y2 = int(y1 + h * 0.18)
        if head_y2 > y1:
            head_crop = hsv[y1:head_y2, x1:x2]
            if head_crop.size > 0:
                yellow_mask = cv2.inRange(head_crop, np.array([15, 70, 70]), np.array([35, 255, 255]))
                white_mask = cv2.inRange(head_crop, np.array([0, 0, 180]), np.array([180, 45, 255]))
                blue_mask = cv2.inRange(head_crop, np.array([90, 60, 60]), np.array([135, 255, 255]))
                
                helmet_pixels = cv2.countNonZero(yellow_mask) + cv2.countNonZero(white_mask) + cv2.countNonZero(blue_mask)
                if (helmet_pixels / head_crop.size) > 0.08:
                    detections["helmet"] = True

        # 2. Safety Vest Detection (Middle 45% of box)
        vest_y1 = int(y1 + h * 0.25)
        vest_y2 = int(y1 + h * 0.70)
        if vest_y2 > vest_y1:
            vest_crop = hsv[vest_y1:vest_y2, x1:x2]
            if vest_crop.size > 0:
                green_mask = cv2.inRange(vest_crop, np.array([25, 70, 70]), np.array([55, 255, 255]))
                orange_mask = cv2.inRange(vest_crop, np.array([0, 80, 80]), np.array([18, 255, 255]))
                
                vest_pixels = cv2.countNonZero(green_mask) + cv2.countNonZero(orange_mask)
                if (vest_pixels / vest_crop.size) > 0.12:
                    detections["vest"] = True
                    
        # Simple toggle variation for goggles
        if (x1 + y1) % 8 == 0:
            detections["goggles"] = False

        return detections

    def _draw_hud_grid(self, frame):
        """Applies tech scan lines and HUD crosshairs"""
        h, w, _ = frame.shape
        overlay = frame.copy()
        for x in range(0, w, 40):
            cv2.line(overlay, (x, 0), (x, h), (255, 255, 255), 1)
        for y in range(0, h, 40):
            cv2.line(overlay, (0, y), (w, y), (255, 255, 255), 1)
        cv2.addWeighted(overlay, 0.03, frame, 0.97, 0, frame)

    def _detect_restricted_zone_intersection(self, person_box, zone_pts):
        """Check if bottom-center of bounding box intersects zone polygon"""
        if zone_pts is None or len(zone_pts) < 3:
            return False
        x1, y1, x2, y2 = person_box
        feet_x = int((x1 + x2) / 2)
        feet_y = int(y2)
        return cv2.pointPolygonTest(zone_pts, (feet_x, feet_y), False) >= 0

    def _generate_synthetic_frame(self):
        """Generates dynamic factory floor scenes to run detections on when webcam is unavailable"""
        frame = np.zeros((480, 640, 3), dtype=np.uint8)
        # Gradient background
        for y in range(480):
            color_val = int(14 + (y / 480) * 16)
            frame[y, :] = (color_val, color_val + 2, color_val + 5)
            
        # Draw background structural layouts
        if self.active_zone_key == "assembly":
            cv2.rectangle(frame, (80, 180), (480, 240), (40, 35, 30), -1)
            cv2.rectangle(frame, (80, 180), (480, 240), (80, 70, 60), 2)
            for ox in range(90, 480, 40):
                cv2.rectangle(frame, (ox, 185), (ox + 15, 235), (20, 20, 20), -1)
        elif self.active_zone_key == "chemical":
            cv2.circle(frame, (240, 160), 50, (60, 20, 20), -1)
            cv2.circle(frame, (240, 160), 50, (180, 40, 40), 3)
            cv2.putText(frame, "TANK 09: HAZARDOUS ACID", (170, 95), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 60, 255), 1, cv2.LINE_AA)
        else:
            cv2.rectangle(frame, (400, 80), (520, 160), (30, 35, 40), -1)
            cv2.rectangle(frame, (400, 80), (520, 160), (100, 100, 100), 2)
            cv2.putText(frame, "BAY 01 CARGO", (415, 120), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, (120, 120, 120), 1, cv2.LINE_AA)
            
        # Update Forklift
        if self.active_zone_key in ["dock", "corridor"]:
            f = self.sim_forklift
            f["x"] += f["vx"]
            f["y"] += f["vy"]
            if f["x"] < 50 or f["x"] > 520: f["vx"] *= -1
            if f["y"] < 180 or f["y"] > 350: f["vy"] *= -1
            
            fx, fy = int(f["x"]), int(f["y"])
            fw, fh = f["width"], f["height"]
            
            cv2.rectangle(frame, (fx, fy), (fx + fw, fy + fh), (0, 180, 245), -1)
            cv2.rectangle(frame, (fx, fy), (fx + fw, fy + fh), (0, 0, 0), 2)
            cv2.line(frame, (fx - 15, fy + fh - 10), (fx, fy + fh - 10), (100, 100, 100), 4)
            cv2.line(frame, (fx - 15, fy + fh - 10), (fx - 15, fy + fh - 25), (100, 100, 100), 3)
            cv2.rectangle(frame, (fx + 20, fy + 5), (fx + fw - 20, fy + 25), (30, 30, 30), -1)
            cv2.putText(frame, "FORKLIFT", (fx + 10, fy + 40), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 0, 0), 1, cv2.LINE_AA)

        # Update workers
        for w in self.sim_workers:
            w["fall_timer"] -= 1
            if w["fall_timer"] <= 0:
                if w["state"] == "walking":
                    w["state"] = "fell"
                    w["fall_timer"] = 100
                else:
                    w["state"] = "walking"
                    w["fall_timer"] = random.randint(250, 600)
            
            if w["state"] == "walking":
                w["x"] += w["vx"]
                w["y"] += w["vy"]
                if w["x"] < 40 or w["x"] > 600: w["vx"] *= -1
                if w["y"] < 80 or w["y"] > 400: w["vy"] *= -1
                
            rx, ry = int(w["x"]), int(w["y"])
            
            w["breadcrumbs"].append((rx, ry))
            if len(w["breadcrumbs"]) > 18:
                w["breadcrumbs"].pop(0)
                
            if w["state"] == "fell":
                cv2.circle(frame, (rx - 25, ry + 15), 10, (200, 220, 255), -1)
                if w["ppe"]["helmet"]:
                    cv2.circle(frame, (rx - 25, ry + 15), 10, (0, 200, 255), -1)
                vest_color = (0, 255, 60) if w["ppe"]["vest"] else (150, 80, 80)
                cv2.rectangle(frame, (rx - 15, ry + 5), (rx + 25, ry + 25), vest_color, -1)
                cv2.line(frame, (rx + 25, ry + 15), (rx + 45, ry + 20), (100, 100, 100), 3)
            else:
                cv2.circle(frame, (rx, ry - 18), 10, (200, 220, 255), -1)
                if w["ppe"]["helmet"]:
                    cv2.circle(frame, (rx, ry - 18), 10, (0, 200, 255), -1)
                vest_color = (0, 230, 255) if w["ppe"]["vest"] else (150, 100, 100)
                cv2.rectangle(frame, (rx - 14, ry - 8), (rx + 14, ry + 18), vest_color, -1)
                cv2.line(frame, (rx - 14, ry - 5), (rx - 20, ry + 15), (100, 100, 100), 2)
                cv2.line(frame, (rx + 14, ry - 5), (rx + 20, ry + 15), (100, 100, 100), 2)
                cv2.line(frame, (rx - 7, ry + 18), (rx - 10, ry + 35), (50, 50, 50), 3)
                cv2.line(frame, (rx + 7, ry + 18), (rx + 10, ry + 35), (50, 50, 50), 3)

        return frame

    def get_frame(self):
        """Captures frame, runs YOLO/HOG detections, performs safety overlays, and returns bytes + alerts"""
        frame = None
        
        # Non-blocking fetch of latest frame from background thread
        if not self.is_fallback_sim and self.running:
            with self.lock:
                if self.latest_frame is not None:
                    frame = self.latest_frame.copy()
                    
        # Fall back to simulation layout if camera has not returned a frame yet
        if frame is None:
            frame = self._generate_synthetic_frame()

        frame = cv2.resize(frame, (640, 480))
        self.frame_count += 1
        h, w, _ = frame.shape
        alerts = []

        # 1. Restricted Safety Zone Rendering
        zone_pts = self.restricted_zones.get(self.active_zone_key, np.array([], dtype=np.int32))
        has_zone = self.active_detectors["zones"] and len(zone_pts) > 0
        
        if has_zone and self.show_heatmap:
            overlay = frame.copy()
            cv2.fillPoly(overlay, [zone_pts], (0, 0, 255))
            cv2.addWeighted(overlay, 0.12, frame, 0.88, 0, frame)
            cv2.polylines(frame, [zone_pts], True, (0, 80, 255), 2)
            cv2.putText(frame, "RESTRICTED BOUNDARY - PERIMETER ACTIVE", (zone_pts[0][0] + 5, zone_pts[0][1] - 8),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 80, 255), 1, cv2.LINE_AA)

        # 2. RUN AI DETECTIONS (YOLO weights vs OpenCV Fallbacks)
        detected_persons = []
        detected_helmets = []
        detected_vests = []
        detected_goggles = []
        detected_no_helmets = []
        detected_no_vests = []
        
        has_custom_yolo_classes = False
        
        if self.model is not None:
            try:
                results = self.model(frame, verbose=False)[0]
                
                class_names = [v.lower() for v in results.names.values()]
                custom_keywords = ["helmet", "vest", "goggles", "hardhat", "jacket", "no-helmet", "no-vest"]
                has_custom_yolo_classes = any(any(kw in name for kw in custom_keywords) for name in class_names)
                
                for box in results.boxes:
                    cls_id = int(box.cls[0])
                    conf = float(box.conf[0])
                    if conf < self.confidence_threshold:
                        continue
                    
                    name = results.names[cls_id].lower()
                    x1, y1, x2, y2 = map(int, box.xyxy[0])
                    
                    if name in ["person", "worker"] or cls_id == 0:
                        detected_persons.append({
                            "box": [x1, y1, x2, y2],
                            "conf": conf,
                            "helmet": False, "vest": False, "goggles": True, "state": "walking"
                        })
                    elif name in ["helmet", "hardhat", "safety-helmet", "headwear"]:
                        detected_helmets.append([x1, y1, x2, y2])
                    elif name in ["vest", "safety-vest", "high-vis-vest", "jacket", "reflective-vest"]:
                        detected_vests.append([x1, y1, x2, y2])
                    elif name in ["goggles", "safety-goggles", "glasses", "safety-glasses"]:
                        detected_goggles.append([x1, y1, x2, y2])
                    elif name in ["no-helmet", "no-hardhat", "no-helmet-worn"]:
                        detected_no_helmets.append([x1, y1, x2, y2])
                    elif name in ["no-vest", "no-safety-vest", "no-jacket"]:
                        detected_no_vests.append([x1, y1, x2, y2])
            except Exception as e:
                print(f"[VisionProcessor] YOLO Error: {e}")

        # If YOLO did not execute or found no one, utilize HOG fallback
        if len(detected_persons) == 0:
            if self.is_fallback_sim or not self.running:
                for idx, sw in enumerate(self.sim_workers):
                    rx, ry = int(sw["x"]), int(sw["y"])
                    if sw["state"] == "fell":
                        box = [rx - 45, ry, rx + 45, ry + 35]
                    else:
                        box = [rx - 25, ry - 35, rx + 25, ry + 40]
                    detected_persons.append({
                        "box": box,
                        "conf": 0.92 + random.uniform(-0.02, 0.03),
                        "helmet": sw["ppe"]["helmet"],
                        "vest": sw["ppe"]["vest"],
                        "goggles": sw["ppe"]["goggles"],
                        "state": sw["state"],
                        "id": sw["id"],
                        "name": sw["name"],
                        "breadcrumbs": sw["breadcrumbs"]
                    })
            else:
                hog = cv2.HOGDescriptor()
                hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
                boxes, weights = hog.detectMultiScale(frame, winStride=(8, 8), scale=1.05)
                for idx, (x, y, bw, bh) in enumerate(boxes):
                    if bw < 50 or bh < 120: continue
                    detected_persons.append({
                        "box": [x, y, x + bw, y + bh],
                        "conf": float(weights[idx]),
                        "helmet": False, "vest": False, "goggles": True, "state": "walking"
                    })

        # 3. Analyze Compliance & Render AI Overlays
        active_violation_count = 0
        total_workers_count = len(detected_persons)
        compliant_workers_count = 0

        for idx, person in enumerate(detected_persons):
            x1, y1, x2, y2 = person["box"]
            x1, y1 = max(0, x1), max(0, y1)
            x2, y2 = min(w, x2), min(h, y2)
            person["box"] = [x1, y1, x2, y2]
            
            w_id = person.get("id", f"W-{100 + idx}")
            
            if self.is_fallback_sim or not self.running:
                helmet_ok = person["helmet"]
                vest_ok = person["vest"]
                goggles_ok = person["goggles"]
                is_fell = (person["state"] == "fell")
            elif has_custom_yolo_classes:
                helmet_ok = False
                vest_ok = False
                goggles_ok = False
                is_fell = False
                
                for hb in detected_helmets:
                    if box_intersection_over_area(hb, person["box"]) > 0.4:
                        helmet_ok = True
                for vb in detected_vests:
                    if box_intersection_over_area(vb, person["box"]) > 0.4:
                        vest_ok = True
                for gb in detected_goggles:
                    if box_intersection_over_area(gb, person["box"]) > 0.4:
                        goggles_ok = True
                        
                for nh in detected_no_helmets:
                    if box_intersection_over_area(nh, person["box"]) > 0.4:
                        helmet_ok = False
                for nv in detected_no_vests:
                    if box_intersection_over_area(nv, person["box"]) > 0.4:
                        vest_ok = False
            else:
                ppe = self._detect_ppe_opencv(frame, person["box"])
                helmet_ok = ppe["helmet"]
                vest_ok = ppe["vest"]
                goggles_ok = ppe["goggles"]
                is_fell = False

            # A. Fall Detection
            has_fall = False
            if is_fell or ((x2 - x1) > (y2 - y1) * 1.3):
                has_fall = True
                alerts.append({
                    "id": f"fall-{int(time.time())}-{idx}",
                    "type": "intrusion",
                    "location": self.active_zone_key,
                    "details": f"CRITICAL: Worker Down / Fall Detected ({w_id})",
                    "severity": "danger",
                    "status": "active"
                })
                active_violation_count += 1

            # B. Restricted Safety Zone Intrusion
            intruded = False
            if has_zone:
                intruded = self._detect_restricted_zone_intersection(person["box"], zone_pts)
                if intruded:
                    alerts.append({
                        "id": f"intrusion-{int(time.time())}-{idx}",
                        "type": "intrusion",
                        "location": self.active_zone_key,
                        "details": f"Safety Breach: Restricted Zone Intrusion ({w_id})",
                        "severity": "danger",
                        "status": "active"
                    })
                    active_violation_count += 1

            # C. PPE Safety compliance rules
            ppe_failed = False
            if self.active_detectors["helmet"] and not helmet_ok:
                alerts.append({
                    "id": f"helmet-{int(time.time())}-{idx}",
                    "type": "helmet",
                    "location": self.active_zone_key,
                    "details": f"Missing PPE: Helmet Violation ({w_id})",
                    "severity": "warning",
                    "status": "active"
                })
                ppe_failed = True
                
            if self.active_detectors["vest"] and not vest_ok:
                alerts.append({
                    "id": f"vest-{int(time.time())}-{idx}",
                    "type": "vest",
                    "location": self.active_zone_key,
                    "details": f"Missing PPE: High-Vis Vest Violation ({w_id})",
                    "severity": "warning",
                    "status": "active"
                })
                ppe_failed = True

            if self.active_detectors["goggles"] and not goggles_ok:
                alerts.append({
                    "id": f"goggles-{int(time.time())}-{idx}",
                    "type": "goggles",
                    "location": self.active_zone_key,
                    "details": f"Missing PPE: Safety Glasses Violation ({w_id})",
                    "severity": "warning",
                    "status": "active"
                })
                ppe_failed = True

            if ppe_failed:
                active_violation_count += 1
            if not ppe_failed and not intruded and not has_fall:
                compliant_workers_count += 1

            # D. Render worker breadcrumb walking paths
            if (self.is_fallback_sim or not self.running) and "breadcrumbs" in person:
                crumbs = person["breadcrumbs"]
                if len(crumbs) > 1:
                    for c_idx in range(1, len(crumbs)):
                        alpha = int(255 * (c_idx / len(crumbs)))
                        crumb_color = (0, 0, 255) if intruded else (255, 180, 0)
                        cv2.line(frame, crumbs[c_idx - 1], crumbs[c_idx], crumb_color, 2)

            # E. Render bounding box, body skeleton, and floating details HUD
            if self.show_boxes:
                if has_fall:
                    box_color = (0, 0, 255)
                elif intruded:
                    box_color = (0, 0, 255)
                elif ppe_failed:
                    box_color = (0, 140, 255)
                else:
                    box_color = (0, 200, 0)

                cv2.rectangle(frame, (x1, y1), (x2, y2), box_color, 2)
                l_sz = 14
                cv2.line(frame, (x1, y1), (x1 + l_sz, y1), box_color, 4)
                cv2.line(frame, (x1, y1), (x1, y1 + l_sz), box_color, 4)
                cv2.line(frame, (x2, y2), (x2 - l_sz, y2), box_color, 4)
                cv2.line(frame, (x2, y2), (x2, y2 - l_sz), box_color, 4)

                banner_lbl = f"{w_id} | {person['name'] if 'name' in person else 'Worker'}"
                if has_fall: banner_lbl += " [FALL DETECTED]"
                elif intruded: banner_lbl += " [ZONE BREACH]"
                
                cv2.rectangle(frame, (x1, y1 - 22), (x1 + 160, y1), box_color, -1)
                cv2.putText(frame, banner_lbl, (x1 + 5, y1 - 7),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.35, (255, 255, 255), 1, cv2.LINE_AA)

                # Floating HUD tags for PPE items beside bounding box
                hud_x = x2 + 6
                hud_y = y1 + 15
                
                def draw_capsule(img, name, status, x, y):
                    c = (0, 200, 0) if status else (0, 0, 230)
                    cv2.rectangle(img, (x, y - 10), (x + 60, y + 5), (15, 15, 15), -1)
                    cv2.rectangle(img, (x, y - 10), (x + 60, y + 5), c, 1)
                    cv2.putText(img, name, (x + 5, y - 1), cv2.FONT_HERSHEY_SIMPLEX, 0.3, c, 1)

                if self.active_detectors["helmet"]:
                    draw_capsule(frame, "HELMET", helmet_ok, hud_x, hud_y)
                    hud_y += 18
                if self.active_detectors["vest"]:
                    draw_capsule(frame, "VEST", vest_ok, hud_x, hud_y)
                    hud_y += 18
                if self.active_detectors["goggles"]:
                    draw_capsule(frame, "GOGGLES", goggles_ok, hud_x, hud_y)

            # F. Body Joints Stick Skeleton
            if self.show_skeleton:
                cx = int((x1 + x2) / 2)
                cy = int((y1 + y2) / 2)
                skeleton_color = (0, 0, 255) if has_fall else (255, 200, 0)
                
                head_pos = (cx - 15, cy) if has_fall else (cx, y1 + int((y2 - y1) * 0.08))
                cv2.circle(frame, head_pos, 5, skeleton_color, -1)
                
                if has_fall:
                    cv2.line(frame, (cx - 20, cy), (cx + 25, cy), skeleton_color, 2)
                    cv2.line(frame, (cx + 25, cy), (cx + 35, cy + 10), skeleton_color, 2)
                else:
                    cv2.line(frame, (cx, y1 + 12), (cx, y2 - 20), skeleton_color, 2)
                    cv2.line(frame, (x1 + 8, y1 + 18), (x2 - 8, y1 + 18), skeleton_color, 2)
                    cv2.line(frame, (cx, y2 - 20), (x1 + 10, y2), skeleton_color, 2)
                    cv2.line(frame, (cx, y2 - 20), (x2 - 10, y2), skeleton_color, 2)

        # 4. AI Collision Avoidance
        if (self.is_fallback_sim or not self.running) and self.active_zone_key in ["dock", "corridor"]:
            f = self.sim_forklift
            fx, fy = int(f["x"] + f["width"]/2), int(f["y"] + f["height"]/2)
            
            for person in detected_persons:
                px, py = int((person["box"][0] + person["box"][2]) / 2), int(person["box"][3])
                
                dist = np.sqrt((fx - px)**2 + (fy - py)**2)
                if dist < 85:
                    color = (0, 0, 255) if (self.frame_count % 10 < 5) else (0, 140, 255)
                    cv2.line(frame, (fx, fy), (px, py), color, 2)
                    cv2.putText(frame, f"COLLISION HAZARD: {int(dist/5)}m", (int((fx + px)/2) - 30, int((fy + py)/2) - 8),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.35, color, 1, cv2.LINE_AA)
                    
                    alerts.append({
                        "id": f"collision-{int(time.time())}",
                        "type": "intrusion",
                        "location": self.active_zone_key,
                        "details": f"MACHINERY COLLISION WARNING: Forklift proximity breach",
                        "severity": "danger",
                        "status": "active"
                    })
                    active_violation_count += 1

        # 5. Global HUD Overlay
        hud_bg = np.zeros((80, 240, 3), dtype=np.uint8)
        cv2.rectangle(hud_bg, (0, 0), (240, 80), (10, 15, 20), -1)
        cv2.addWeighted(hud_bg, 0.45, frame[15:95, 15:255], 0.55, 0, frame[15:95, 15:255])
        cv2.rectangle(frame, (15, 15), (255, 95), (0, 180, 255), 1)
        
        cv2.putText(frame, "AI VISION HUD PRO", (25, 32), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 180, 255), 1, cv2.LINE_AA)
        
        dot_color = (0, 0, 255) if len(alerts) > 0 else (0, 255, 0)
        cv2.circle(frame, (240, 30), 4, dot_color, -1)
        
        compliance_pct = (compliant_workers_count / total_workers_count * 100) if total_workers_count > 0 else 100
        
        cv2.putText(frame, f"Workers Monitored: {total_workers_count}", (25, 48), cv2.FONT_HERSHEY_SIMPLEX, 0.32, (200, 200, 200), 1, cv2.LINE_AA)
        cv2.putText(frame, f"Safety Compliance: {compliance_pct:.1f}%", (25, 62), cv2.FONT_HERSHEY_SIMPLEX, 0.32, (0, 255, 0) if compliance_pct > 90 else (0, 140, 255), 1, cv2.LINE_AA)
        
        model_name = os.path.basename(self.model_path) if self.model_path else "YOLOv8-Fallback"
        if has_custom_yolo_classes:
            model_name += " (Custom PPE)"
        cv2.putText(frame, f"Model: {model_name}", (25, 76), cv2.FONT_HERSHEY_SIMPLEX, 0.32, (150, 150, 150), 1, cv2.LINE_AA)

        # 6. Flash red alert screen frame when critical threat is active
        if len(alerts) > 0:
            if self.frame_count % 8 < 4:
                cv2.rectangle(frame, (0, 0), (w, h), (0, 0, 230), 12)
                cv2.putText(frame, "SAFETY BREACH DETECTED - ALARM ACTIVE", (160, 440), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 0, 255), 2, cv2.LINE_AA)

        # Draw grid
        self._draw_hud_grid(frame)

        ret, buffer = cv2.imencode('.jpg', frame)
        return buffer.tobytes(), alerts

    def __del__(self):
        self.running = False
        if self.read_thread is not None:
            self.read_thread.join(timeout=1.0)
        if self.cap is not None:
            self.cap.release()
