import os
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"

import cv2
import numpy as np
import time
from vision import VisionProcessor

def main():
    print("==============================================================")
    print("IndustrialVision AI: Desktop Edge Visualizer (Pure Python)")
    print("==============================================================")
    
    # Auto-detect local custom model weights named 'best.pt'
    model_path = None
    if os.path.exists("best.pt"):
        model_path = "best.pt"
        print("[main.py] Auto-detecting local custom model weights: best.pt")
    else:
        print("[main.py] No custom model 'best.pt' found in folder. Using default/fallback model.")
        
    # Initialize Vision Processor on camera source 0
    processor = VisionProcessor(source="0", model_path=model_path)
    
    print("\nInteractive Keyboard Controls:")
    print("  [q] - Quit Visualizer Window")
    print("  [h] - Toggle Helmet Detection")
    print("  [v] - Toggle Safety Vest Detection")
    print("  [g] - Toggle Safety Glasses/Goggles Detection")
    print("  [z] - Toggle Restricted Zones monitoring")
    print("  [0-9] - Switch camera source dynamically (e.g. index 0, 1)")
    print("==============================================================")
    
    window_name = "IndustrialVision AI - Desktop Edge Monitor"
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(window_name, 800, 600)
    
    print("\nStarting video stream loop. Press 'q' inside window to quit.")
    
    while True:
        # 1. Capture processed JPEG frame bytes + active alerts from vision processor
        frame_bytes, alerts = processor.get_frame()
        
        # 2. Decode JPEG bytes back to BGR image for OpenCV native display
        nparr = np.frombuffer(frame_bytes, np.uint8)
        frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        # 3. Print alerts in terminal in real-time
        if alerts:
            alert_msgs = ", ".join([a['details'] for a in alerts])
            print(f"\r[ALERTS ACTIVE] {alert_msgs}                               ", end="", flush=True)
        else:
            print("\r[STATUS] Environment Secure. No alerts.                ", end="", flush=True)
            
        # 4. Show image in desktop window
        cv2.imshow(window_name, frame)
        
        # 5. Capture Keyboard Inputs
        key = cv2.waitKey(30) & 0xFF
        
        if key == ord('q'):
            break
        elif key == ord('h'):
            processor.active_detectors["helmet"] = not processor.active_detectors["helmet"]
            print(f"\n[Config Change] Helmet Detection: {'ENABLED' if processor.active_detectors['helmet'] else 'DISABLED'}")
        elif key == ord('v'):
            processor.active_detectors["vest"] = not processor.active_detectors["vest"]
            print(f"\n[Config Change] Safety Vest Detection: {'ENABLED' if processor.active_detectors['vest'] else 'DISABLED'}")
        elif key == ord('g'):
            processor.active_detectors["goggles"] = not processor.active_detectors["goggles"]
            print(f"\n[Config Change] Goggles Detection: {'ENABLED' if processor.active_detectors['goggles'] else 'DISABLED'}")
        elif key == ord('z'):
            processor.active_detectors["zones"] = not processor.active_detectors["zones"]
            print(f"\n[Config Change] Restricted Zone monitoring: {'ENABLED' if processor.active_detectors['zones'] else 'DISABLED'}")
        elif chr(key).isdigit() and key != 255:
            cam_idx = chr(key)
            print(f"\n[Config Change] Connecting to camera source index: {cam_idx}")
            processor.set_source(cam_idx)
            
    cv2.destroyAllWindows()
    print("\nVisualizer closed. Exiting application.")

if __name__ == "__main__":
    main()
